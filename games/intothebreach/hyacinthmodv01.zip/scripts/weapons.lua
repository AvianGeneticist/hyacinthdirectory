local mod = modApi:getCurrentMod()
local path = mod_loader.mods[modApi.currentMod].resourcePath
local weaponPath = path .."img/weapons/"
modApi:appendAsset("img/weapons/fireball.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/fireball.png")
modApi:appendAsset("img/weapons/frostray.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/frostray.png")
modApi:appendAsset("img/weapons/healingenergy.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/healingenergy.png")
modApi:appendAsset("img/weapons/impspawn.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/impspawn.png")
modApi:appendAsset("img/weapons/manipulatorstrike.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/manipulatorstrike.png")
modApi:appendAsset("img/weapons/divestrike.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/divestrike.png")
modApi:appendAsset("img/effects/shotup_imp.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/shotup_imp.png")

Prime_Manipulator = Skill:new{
	Range = RANGE_PROJECTILE,
	PathSize = INT_MAX,
	Name = "Manipulative Strike",
	Description = "Damage and push the target; shields self in melee, does extra damage at range.",
	Icon = "weapons/manipulatorstrike.png",
	Explo = "explopush1_",
	Class = "Prime",
	Damage = 1,
	MaxDamage = 2,
	MeleeRepair = 0,
	RangedDamage = 1,
	PushBack = 0,
	BackShot = 0,
	ProjectileArt = "effects/shot_mechtank",
	Push = 1,
	Freeze = 0,
	Acid = 0,
	Flip = 0,
	Fire = 0,
	Shield = 0,
	Upgrades = 2,
	UpgradeCost = {1,2},
	MeleeShield = true,
	Phase = false,
	PhaseShield = false,
	ZoneTargeting = ZONE_DIR,
	TipImage = {
		Unit = Point(3,3),
		Enemy = Point(3,2),
		Enemy2 = Point(1,3),
		Target = Point(1,3),
		Second_Target = Point(3,2),
		Second_Origin = Point(3,3),
	},
}

Prime_Manipulator_A = Prime_Manipulator:new{
		UpgradeDescription = "Melee Manipulative Strikes repair 1 HP. Ranged Manipulative Strikes do 1 extra damage.",
		RangedDamage = 2,
		MeleeRepair = -1,
}
Prime_Manipulator_B = Prime_Manipulator:new{
		UpgradeDescription = "Increases the damage of the Manipulative Strike",
		Damage = 2,
}
Prime_Manipulator_AB = Prime_Manipulator:new{
		Damage = 2,
		RangedDamage = 2,
		MeleeRepair = -1,
}

function Prime_Manipulator:GetTargetArea(p1)

	if not self.Phase then
		return Board:GetSimpleReachable(p1, self.PathSize, self.CornersAllowed)
	else
		local ret = PointList()
	
		for dir = DIR_START, DIR_END do
			for i = 1, 8 do
				local curr = Point(p1 + DIR_VECTORS[dir] * i)
				if not Board:IsValid(curr) then
					break
				end
				
				ret:push_back(curr)
				
				if Board:IsBlocked(curr,PATH_PHASING) then
					break
				end
			end
		end
	
	return ret
	
	end
end

function Prime_Manipulator:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)

	if self.PushBack == 1 then
		local selfDam = SpaceDamage(p1, self.SelfDamage, GetDirection(p1 - p2))
		ret:AddDamage(selfDam)
	end

	local pathing = self.Phase and PATH_PHASING or PATH_PROJECTILE
	local target = GetProjectileEnd(p1,p2,pathing)  
	
	local damage = SpaceDamage(target, self.Damage + self.RangedDamage)
	if self.Flip == 1 then
		damage = SpaceDamage(target,self.Damage,DIR_FLIP)
	end

for i = DIR_START, DIR_END do
  local curr = GetProjectileEnd(p1,p2,pathing) + DIR_VECTORS[i]
  if curr == p1 then
		local shield = SpaceDamage(p1,self.MeleeRepair)
		shield.iShield = 1
		ret:AddDamage(shield)
		damage = SpaceDamage(target, self.Damage)
	end
end
	
	if self.Phase and Board:IsBuilding(target) then
		damage.sAnimation = ""
		damage.iDamage = 0
	end
	if self.Push == 1 then
		damage.iPush = direction
	end
	damage.iAcid = self.Acid
	damage.iFrozen = self.Freeze
	damage.iFire = self.Fire
	damage.iShield = self.Shield
	damage.sAnimation = self.Explo..direction
	
	ret:AddProjectile(damage, self.ProjectileArt, NO_DELAY)--"effects/shot_mechtank")
		
	if self.BackShot == 1 then
		local backdir = GetDirection(p1 - p2)
		local target2 = GetProjectileEnd(p1,p1 + DIR_VECTORS[backdir])

		if target2 ~= p1 then
			damage = SpaceDamage(target2, self.Damage, backdir)
			damage.sAnimation = self.Explo..backdir
			ret:AddProjectile(damage,self.ProjectileArt)
		end
	end

	
	if self.PhaseShield then
		local temp = p1 + DIR_VECTORS[direction]
		while true do
			if Board:IsBuilding(temp) then
				damage = SpaceDamage(temp, 0)
				damage.iShield = 1
				ret:AddDamage(damage)
			end
		
			if temp == target then
				break
			end
			
			temp = temp + DIR_VECTORS[direction]
		end
	end
	
	return ret
end

Ranged_TricksterPuppetBolt = ArtilleryDefault:new{
	Name = "Fireball",
	Description = "Damages an area and enflames the target tile.",
	Class = "Ranged",
	Icon = "weapons/fireball.png",
	UpShot = "effects/shotup_fireball.png",
	ArtilleryStart = 2,
	ArtillerySize = 8,
	BuildingDamage = true,
	Push = 0,
	DamageOuter = 1,
	DamageCenter = 1,
	WideFire = false,
	PowerCost = 0, --AE Change
	Damage = 1,---USED FOR TOOLTIPS
	BounceAmount = 1,
	Explosion = "",
	ExplosionCenter = "ExploArt1",
	ExplosionOuter = "",
	Upgrades = 2,
	UpgradeCost = {1,3},
	LaunchSound = "/weapons/artillery_volley",
	ImpactSound = "/impact/generic/explosion",
	TipImage = {
		Unit = Point(2,0),
		Enemy = Point(2,3),
		Enemy2 = Point(3,3),
		Enemy3 = Point(1,3),
		Enemy4 = Point(2,2),
		Building = Point(2,4),
		Target = Point(2,3),
	},
}


Ranged_TricksterPuppetBolt_A = Ranged_TricksterPuppetBolt:new{
		UpgradeDescription = "Prevents damage to buildings.",
		BuildingDamage = false,
}

Ranged_TricksterPuppetBolt_B = Ranged_TricksterPuppetBolt:new{
		UpgradeDescription = "Increases damage, particularly in the center.",
		DamageOuter = 2,
		DamageCenter = 3,
}

Ranged_TricksterPuppetBolt_AB = Ranged_TricksterPuppetBolt:new{
		DamageOuter = 2,
		DamageCenter = 3,
		BuildingDamage = false,
}

function Ranged_TricksterPuppetBolt:GetSkillEffect(p1, p2)	
	local ret = SkillEffect()
	
	local damage = SpaceDamage(p2,self.DamageCenter)
	damage.iFire = 1
	damage.sAnimation = self.ExplosionCenter
	
	if not self.BuildingDamage and Board:IsBuilding(p2) then		-- Target Buildings - 
		damage.iDamage = DAMAGE_ZERO
	end
	
	ret:AddBounce(p1, 1)
	ret:AddArtillery(damage, self.UpShot)
	
	if self.BounceAmount ~= 0 then	ret:AddBounce(p2, self.BounceAmount) end
	
	for dir = 0, 3 do
		damage = SpaceDamage(p2 + DIR_VECTORS[dir],  self.DamageOuter)
		
		if self.Push == 1 then
			damage.iPush = dir
		end
		damage.sAnimation = self.OuterAnimation..dir
		
		if not self.BuildingDamage and Board:IsBuilding(p2 + DIR_VECTORS[dir]) then	
			damage.iDamage = 0
			damage.sAnimation = "airpush_"..dir
		end
		
		ret:AddDamage(damage)
		if self.BounceOuterAmount ~= 0 then	ret:AddBounce(p2 + DIR_VECTORS[dir], self.BounceOuterAmount) end  
	end

	return ret
end

Ranged_TricksterFrostBeam = LaserDefault:new{
	Name = "Frost Ray",
	Description = "A ray of damaging frost that protects buildings with ice.",
	Icon = "weapons/frostray.png",
	Class = "Ranged",
	Damage = 2,
	MinDamage = 2,
	Limited = 2,
	PowerCost = 0,
	Smoke = 0,
	Acid = 0,
	Fire = 0,
	Freeze = 0,
	Upgrades = 2,
	UpgradeCost = {1,2},
	FriendlyDamage = true,
	LaserAnimation = "ExploAir1",
	LaserArt = "effects/laser_freeze",
	LaunchSound = "/weapons/burst_beam",
	TipImage = {
		Unit = Point(2,5),
		Enemy = Point(2,4),
		Building = Point(2,3),
		Enemy2 = Point(2,2),
		Friendly = Point(2,1),
		Enemy3 = Point(2,0),
		Target = Point(2,4),
	},
}

Ranged_TricksterFrostBeam_A = Ranged_TricksterFrostBeam:new{
		UpgradeDescription = "Increases maximum number of uses by 1.",
		Limited = 3,
}

Ranged_TricksterFrostBeam_B = Ranged_TricksterFrostBeam:new{
		UpgradeDescription = "Striking allies deals no damage and increases beam damage by 1.",
		FriendlyDamage = false,
}

Ranged_TricksterFrostBeam_AB = Ranged_TricksterFrostBeam:new{
		Limited = 3,
		FriendlyDamage = false,
}

function Ranged_TricksterFrostBeam:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)
	local point = p1 + DIR_VECTORS[direction]
	local damage = self.Damage
	local minDamage = self.MinDamage or 1
	local start = point - DIR_VECTORS[direction]
	
	if forced_end ~= nil then
		LOG("Forced end = "..forced_end:GetString())
	else
		LOG("No forced end!")
	end
	ret:AddBounce(p1,2)
	while Board:IsValid(point) do
	
		local temp_damage = damage  --This is so that if damage is set to 0 because of an ally, it doesn't affect the damage calculation of the laser.
		
		if not self.FriendlyDamage and Board:IsPawnTeam(point, TEAM_PLAYER) then
			damage = damage + 3
			temp_damage = DAMAGE_ZERO
		end

		if Board:IsBuilding(point) then
			temp_damage = DAMAGE_ZERO
		end

		local dam = SpaceDamage(point, temp_damage)
		
		dam.iSmoke = self.Smoke
		dam.iAcid = self.Acid
		dam.iFire = self.Fire
		dam.iFrozen = self.Freeze

		if Board:IsBuilding(point) then
			dam.iFrozen = 1
		end
		
		-- if it's the end of the line (ha), add the laser art -- not pretty
		if forced_end == point or Board:GetTerrain(point) == TERRAIN_MOUNTAIN or not Board:IsValid(point + DIR_VECTORS[direction]) then
			if queued then 
				ret:AddQueuedProjectile(dam,self.LaserArt)
			else
				ret:AddProjectile(start,dam,self.LaserArt,FULL_DELAY)
			end
			break
		else
			if queued then
				ret:AddQueuedDamage(dam)  
			else
				ret:AddDamage(dam)   --JUSTIN TEST
			end
		end
		
		damage = damage - 1
		if damage < minDamage then damage = minDamage end
					
		point = point + DIR_VECTORS[direction]	
	end
	
	
	return ret
end

--- RECONCILANT SKILLS

Heal_ReconcilantPuppet = Skill:new{	
	Name = "Healing Energy",
	Description = "Recovers 2 Health to the target, removing Fire and A.C.I.D.",
	Icon = "weapons/healingenergy.png",
	Class = "Science",
	Amount = -2,
	AreaHeal = false,
	ArtillerySize = 3,
	Upgrades = 1,
	UpgradeCost = {2},
	TipImage = {
		Unit_Damaged = Point(2,0),
		Mountain = Point(2,1),
		Friendly_Damaged = Point(2,3),
		Friendly_Damaged2 = Point(3,3),
		Friendly_Damaged3 = Point(1,3),
		Target = Point(2,3),
	},
}

Heal_ReconcilantPuppet_A = Heal_ReconcilantPuppet:new{	
	UpgradeDescription = "Increases max range by 2 and affects an area.",
	Amount = -2,
	AreaHeal = true,
	ArtillerySize = 5,
}

function Heal_ReconcilantPuppet:GetTargetArea(point)
	local ret = PointList()
	
	for dir = DIR_START, DIR_END do
		for i = 1, self.ArtillerySize do
			local curr = Point(point + DIR_VECTORS[dir] * i)
			if not Board:IsValid(curr) then
				break
			end
			
			if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
				ret:push_back(curr)
			end

		end
	end
	
	return ret
end

function Heal_ReconcilantPuppet:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local selfdamage = SpaceDamage(p1,self.Amount)
	selfdamage.iFire = EFFECT_REMOVE
	selfdamage.iAcid = EFFECT_REMOVE
	local damage = SpaceDamage(p2,self.Amount)
	damage.iFire = EFFECT_REMOVE
	damage.iAcid = EFFECT_REMOVE

	if self.AreaHeal then
		for dir = 0, 3 do
			local damagearea = SpaceDamage(p2 + DIR_VECTORS[dir],  self.Amount)
			damagearea.iFire = EFFECT_REMOVE
			damagearea.iAcid = EFFECT_REMOVE
			ret:AddDamage(damagearea)
		end
	end
	
	ret:AddDamage(selfdamage)
	ret:AddDamage(damage)
	
	return ret
end

Deploy_ImpPuppet = Pawn:new{
	Name = "Imp Puppet",
	Health = 1,
	MoveSpeed = 4,
	Flying = true,
    Image = "ImpPuppet",
    ImageOffset = 14,
	SkillList = { "Deploy_ImpStrike" },
	--SoundLocation = "/support/civilian_tank/", -- not implemented
	SoundLocation = "/mech/brute/tank",
	DefaultTeam = TEAM_PLAYER,
	ImpactMaterial = IMPACT_METAL,
	Corpse = true,
	--Corporate = true
}

Deploy_ImpPuppetA = Deploy_ImpPuppet:new{Health = 2, SkillList = {"Deploy_ImpStrike2"}}

Deploy_ImpStrike = Prime_Punchmech:new{  
	Class = "",
	Name = "Divestrike",
	Description = "Dash to a nearby tile, damaging and pushing whatever is on it.",
	Icon = "weapons/divestrike.png",
	Rarity = 0,
	Explosion = "",
	LaunchSound = "/weapons/titan_fist",
	Range = 2, -- Tooltip?
	PathSize = 3,
	Damage = 1,
	Upgrades = 0,
	PushBack = false,
	Flip = false,
	Dash = true,
	Shield = false,
	Projectile = false,
	Push = 1, --Mostly for tooltip, but you could turn it off for some unknown reason
	TipImage = {
		Unit = Point(2,1),
		Target = Point(2,3),
		Enemy = Point(2,3),
		CustomPawn = "Deploy_ImpPuppet",
	},
}

Deploy_ImpStrike2 = Deploy_ImpStrike:new{  
	Class = "",
	Name = "Divestrike",
	Description = "Dash to a nearby tile, damaging and pushing whatever is on it.",
	Icon = "weapons/divestrike.png",
	Rarity = 0,
	Explosion = "",
	LaunchSound = "/weapons/titan_fist",
	Range = 3, -- Tooltip?
	PathSize = 4,
	Damage = 2,
	Upgrades = 0,
	PushBack = false,
	Flip = false,
	Dash = true,
	Shield = false,
	Projectile = false,
	Push = 1, --Mostly for tooltip, but you could turn it off for some unknown reason
	TipImage = {
		Unit = Point(2,1),
		Target = Point(2,3),
		Enemy = Point(2,3),
		CustomPawn = "Deploy_ImpPuppet",
	},
}

function Deploy_ImpStrike:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)

	local doDamage = true
	local target = GetProjectileEnd(p1,p2,PATH_PROJECTILE)
	local push_damage = self.Flip and DIR_FLIP or direction
	local damage = SpaceDamage(target, self.Damage, push_damage)
	damage.sAnimation = "explopunch1_"..direction
	if self.Flip then damage.sAnimation = "SwipeClaw2" end  -- Change the animation if it's a flip
    
	if self.Shield then
		local shield = SpaceDamage(p1,0)
		shield.iShield = EFFECT_CREATE
		ret:AddDamage(shield)
	end
	
    if self.Dash then
       
        if not Board:IsBlocked(target,PATH_PROJECTILE) then -- dont attack an empty edge square, just run to the edge
	    	doDamage = false
		    target = target + DIR_VECTORS[direction]
    	end
    	
    	ret:AddCharge(Board:GetSimplePath(p1, p2 - DIR_VECTORS[direction]), FULL_DELAY)
    elseif self.Projectile and target:Manhattan(p1) ~= 1 then
		damage.loc = target
		ret:AddDamage(SpaceDamage(p1,0,(direction+2)%4))
		ret:AddProjectile(damage, "effects/shot_fist")
		doDamage = false--damage covered here
	else
		target = p2
	end

	
	if doDamage then
		damage.loc = p2
		ret:AddMelee(p2 - DIR_VECTORS[direction], damage)
	end
	
	if self.PushBack then
		ret:AddDamage(SpaceDamage(p1, 0, GetDirection(p1 - p2)))
	end
	return ret
end	

DeploySkill_ImpPuppet = Deployable:new{
	Name = "Spawn Imp",
	Description = "Spawn an Imp Puppet to help in combat. Limited uses.",
	Icon = "weapons/impspawn.png",
	Class = "Science",
	Rarity = 1,
	Deployed = "Deploy_ImpPuppet",
	Projectile = "effects/shotup_imp.png",
	Limited = 2,
	Twins = false,
	Upgrades = 2,
	UpgradeCost = {1,2},
	LaunchSound = "/weapons/deploy_tank",
	ImpactSound = "/impact/generic/mech",
	TipImage = {
		Unit = Point(2,3),
		Target = Point(2,1),
		Enemy = Point(4,1),
		Second_Origin = Point(2,1),
		Second_Target = Point(4,1),
	},
}

function DeploySkill_ImpPuppet:GetTargetArea(point)
	local ret = PointList()

	local impPresent = 0
	local pawns = extract_table(Board:GetPawns(TEAM_PLAYER))
	for i, pawn_id in ipairs(pawns) do
		local pawn = Board:GetPawn(Board:GetPawnSpace(pawn_id))
		local t = pawn:GetType()
		if t == "Deploy_ImpPuppet" or t == "Deploy_ImpPuppetA" then
			impPresent = impPresent + 1
		end
	end

	if self.Twins and impPresent == 1 then
		for dir = DIR_START, DIR_END do
			for i = 2, self.ArtillerySize do
				local curr = Point(point + DIR_VECTORS[dir] * i)
				local curr2 = Point(point + DIR_VECTORS[dir] * (i - 1))
				if not Board:IsValid(curr) or not Board:IsValid(curr2) then
					break
				end
				
				if (not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND)) and (not self.OnlyEmpty or not Board:IsBlocked(curr2,PATH_GROUND)) then
					ret:push_back(curr)
				end

			end
		end
	else
		for dir = DIR_START, DIR_END do
			for i = 2, self.ArtillerySize do
				local curr = Point(point + DIR_VECTORS[dir] * i)
				if not Board:IsValid(curr) then
					break
				end
				
				if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
					ret:push_back(curr)
				end

			end
		end
	end
	
	return ret
end

function DeploySkill_ImpPuppet:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local dir = GetDirection(p2 - p1)
	
	local impPresent = 0
	local pawns = extract_table(Board:GetPawns(TEAM_PLAYER))
	for i, pawn_id in ipairs(pawns) do
		local pawn = Board:GetPawn(Board:GetPawnSpace(pawn_id))
		local t = pawn:GetType()
		if t == "Deploy_ImpPuppet" or t == "Deploy_ImpPuppetA" then
			impPresent = impPresent + 1
		end
	end

	if self.Twins and impPresent == 1 then
		local damage = SpaceDamage(p2,0)
		local damage2 = SpaceDamage(p2 - DIR_VECTORS[dir],0)
		damage.sPawn = self.Deployed
		damage2.sPawn = self.Deployed
		ret:AddArtillery(damage,self.Projectile)
		ret:AddArtillery(damage2,self.Projectile)
		return ret
	else
		local damage = SpaceDamage(p2,0)
		damage.sPawn = self.Deployed
		ret:AddArtillery(damage,self.Projectile)
		return ret
	end
end

DeploySkill_ImpPuppet_A = DeploySkill_ImpPuppet:new{
		Deployed = "Deploy_ImpPuppet",
		UpgradeDescription = "Makes the second spawn each mission spawn a second Imp.",
		Twins = true,
		TipImage = {
		Unit = Point(2,3),
		Target = Point(2,1),
		Enemy = Point(4,1),
		Second_Origin = Point(2,1),
		Second_Target = Point(4,1),
	},
}
DeploySkill_ImpPuppet_B = DeploySkill_ImpPuppet:new{
		Deployed = "Deploy_ImpPuppetA",
		UpgradeDescription = "Increases the health and damage of Imps.",
}
DeploySkill_ImpPuppet_AB = DeploySkill_ImpPuppet:new{
		Deployed = "Deploy_ImpPuppetA",
		Twins = true,
}