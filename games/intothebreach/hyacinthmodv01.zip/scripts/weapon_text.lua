local Weapon_Texts = {
Prime_Manipulator_Upgrade1 = "Increased Specials",
Prime_Manipulator_Upgrade2 = "+1 Damage",

Ranged_TricksterPuppetBolt_Upgrade1 = "Buildings Immune",
Ranged_TricksterPuppetBolt_Upgrade2 = "+1-2 Damage",

Ranged_TricksterFrostBeam_Upgrade1 = "+1 Uses",
Ranged_TricksterFrostBeam_Upgrade2 = "Ally Boost",

Heal_ReconcilantPuppet_Upgrade1 = "Increased Range/Radius",

DeploySkill_ImpPuppet_Upgrade1 = "Second Shot Twin",
DeploySkill_ImpPuppet_Upgrade2 = "+1 Health/Damage",
}

return Weapon_Texts