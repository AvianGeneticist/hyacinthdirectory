local mod = modApi:getCurrentMod()
local path = mod_loader.mods[modApi.currentMod].resourcePath
local mechPath = path .."img/units/player/"

local files = {
    "blankpuppet.png",
    "blankpuppet_a.png",
    "blankpuppet_w.png",
    "blankpuppet_w_broken.png",
    "blankpuppet_broken.png",
    "blankpuppet_ns.png",
    "blankpuppet_h.png",

    "manipulatorpuppet.png",
    "manipulatorpuppet_a.png",
    "manipulatorpuppet_w.png",
    "manipulatorpuppet_w_broken.png",
    "manipulatorpuppet_broken.png",
    "manipulatorpuppet_ns.png",
    "manipulatorpuppet_h.png",

    "tricksterpuppet.png",
    "tricksterpuppet_a.png",
    "tricksterpuppet_w.png",
    "tricksterpuppet_w_broken.png",
    "tricksterpuppet_broken.png",
    "tricksterpuppet_ns.png",
    "tricksterpuppet_h.png",

    "reconcilantpuppet.png",
    "reconcilantpuppet_a.png",
    "reconcilantpuppet_w.png",
    "reconcilantpuppet_w_broken.png",
    "reconcilantpuppet_broken.png",
    "reconcilantpuppet_ns.png",
    "reconcilantpuppet_h.png",

    "imppuppet.png",
    "imppuppet_a.png",
    "imppuppet_w_broken.png",
    "imppuppet_broken.png",
    "imppuppet_ns.png",
    "imppuppet_h.png",
}


for _, file in ipairs(files) do
    modApi:appendAsset("img/units/player/".. file, mechPath .. file)
end

    modApi:addPalette({
    ID = "PuppetPalette",
    Name = "Hyacinth's Puppets",
    Image = "units/player/blankpuppet_ns.png",
    PlateHighlight = {239,198,237},
    PlateLight     = {214,145,210},
    PlateMid       = {184,103,180},
    PlateDark      = {123,48,119},
    PlateOutline   = {58,19,56},
    PlateShadow    = {116,153,182},
    BodyColor      = {200,223,241},
    BodyHighlight  = {224,240,253},
    }
)

local a=ANIMS
a.BlankPuppet =a.MechUnit:new{Image="units/player/blankpuppet.png", PosX = -15, PosY = -9}
a.BlankPuppeta = a.MechUnit:new{Image="units/player/blankpuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.BlankPuppetw = a.MechUnit:new{Image="units/player/blankpuppet_w.png", -15, PosY = -9}
a.BlankPuppet_broken = a.MechUnit:new{Image="units/player/blankpuppet_broken.png", PosX = -15, PosY = -9 }
a.BlankPuppetw_broken = a.MechUnit:new{Image="units/player/blankpuppet_w_broken.png", PosX = -15, PosY = -9 }
a.BlankPuppet_ns = a.MechIcon:new{Image="units/player/blankpuppet_ns.png"}




BlankPuppet = Pawn:new{
    Name = "Blank Puppet",
    Class = "Prime",
    Health = 3,
    MoveSpeed = 3,
    Massive = true,
    Corpse = true,
    Image = "BlankPuppet",
    ImageOffset = 14,
    SkillList = {"DeploySkill_Tank"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("BlankPuppet")

local a=ANIMS
a.ManipulatorPuppet =a.MechUnit:new{Image="units/player/manipulatorpuppet.png", PosX = -15, PosY = -9}
a.ManipulatorPuppeta = a.MechUnit:new{Image="units/player/manipulatorpuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.ManipulatorPuppetw = a.MechUnit:new{Image="units/player/manipulatorpuppet_w.png", -15, PosY = -9}
a.ManipulatorPuppet_broken = a.MechUnit:new{Image="units/player/manipulatorpuppet_broken.png", PosX = -15, PosY = -9 }
a.ManipulatorPuppetw_broken = a.MechUnit:new{Image="units/player/manipulatorpuppet_w_broken.png", PosX = -15, PosY = -9 }
a.ManipulatorPuppet_ns = a.MechIcon:new{Image="units/player/manipulatorpuppet_ns.png"}


ManipulatorPuppet = Pawn:new{
    Name = "Manipulator Puppet",
    Class = "Prime",
    Health = 3,
    MoveSpeed = 3,
    Massive = true,
    Corpse = true,
    Image = "ManipulatorPuppet",
    ImageOffset = 14,
    SkillList = {"Prime_Manipulator"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("ManipulatorPuppet")




local a=ANIMS
a.TricksterPuppet =a.MechUnit:new{Image="units/player/tricksterpuppet.png", PosX = -15, PosY = -9}
a.TricksterPuppeta = a.MechUnit:new{Image="units/player/tricksterpuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.TricksterPuppetw = a.MechUnit:new{Image="units/player/tricksterpuppet_w.png", -15, PosY = -9}
a.TricksterPuppet_broken = a.MechUnit:new{Image="units/player/tricksterpuppet_broken.png", PosX = -15, PosY = -9 }
a.TricksterPuppetw_broken = a.MechUnit:new{Image="units/player/tricksterpuppet_w_broken.png", PosX = -15, PosY = -9 }
a.TricksterPuppet_ns = a.MechIcon:new{Image="units/player/tricksterpuppet_ns.png"}


TricksterPuppet = Pawn:new{
    Name = "Trickster Puppet",
    Class = "Ranged",
    Health = 2,
    MoveSpeed = 3,
    Massive = true,
    Corpse = true,
    Image = "TricksterPuppet",
    ImageOffset = 14,
    SkillList = {"Ranged_TricksterPuppetBolt", "Ranged_TricksterFrostBeam"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("TricksterPuppet") 



local a=ANIMS
a.ReconcilantPuppet =a.MechUnit:new{Image="units/player/reconcilantpuppet.png", PosX = -15, PosY = -9}
a.ReconcilantPuppeta = a.MechUnit:new{Image="units/player/reconcilantpuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.ReconcilantPuppetw = a.MechUnit:new{Image="units/player/reconcilantpuppet_w.png", -15, PosY = -9}
a.ReconcilantPuppet_broken = a.MechUnit:new{Image="units/player/reconcilantpuppet_broken.png", PosX = -15, PosY = -9 }
a.ReconcilantPuppetw_broken = a.MechUnit:new{Image="units/player/reconcilantpuppet_w_broken.png", PosX = -15, PosY = -9 }
a.ReconcilantPuppet_ns = a.MechIcon:new{Image="units/player/reconcilantpuppet_ns.png"}


ReconcilantPuppet = Pawn:new{
    Name = "Reconcilant Puppet",
    Class = "Science",
    Health = 4,
    MoveSpeed = 2,
    Massive = true,
    Corpse = true,
    Image = "ReconcilantPuppet",
    ImageOffset = 14,
    SkillList = {"Heal_ReconcilantPuppet", "DeploySkill_ImpPuppet"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("ReconcilantPuppet") 



local a=ANIMS
a.ImpPuppet =a.MechUnit:new{Image="units/player/imppuppet.png", PosX = -15, PosY = -9}
a.ImpPuppeta = a.MechUnit:new{Image="units/player/imppuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.ImpPuppetw = a.MechUnit:new{Image="units/player/imppuppet_w.png", -15, PosY = -9}
a.ImpPuppet_broken = a.MechUnit:new{Image="units/player/imppuppet_broken.png", PosX = -15, PosY = -9 }
a.ImpPuppetw_broken = a.MechUnit:new{Image="units/player/imppuppet_w_broken.png", PosX = -15, PosY = -9 }
a.ImpPuppet_ns = a.MechIcon:new{Image="units/player/imppuppet_ns.png"}