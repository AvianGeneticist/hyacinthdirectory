local mod = modApi:getCurrentMod()
local path = mod_loader.mods[modApi.currentMod].resourcePath
local mechPath = path .."img/units/player/"

local files = {
    "myrmecophpuppet.png",
    "myrmecophpuppet_a.png",
    "myrmecophpuppet_w.png",
    "myrmecophpuppet_w_broken.png",
    "myrmecophpuppet_broken.png",
    "myrmecophpuppet_ns.png",
    "myrmecophpuppet_h.png",
}


for _, file in ipairs(files) do
    modApi:appendAsset("img/units/player/".. file, mechPath .. file)
end

modApi:appendAsset("img/weapons/myrmecoph_noflip.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/myrmecoph_noflip.png")
modApi:appendAsset("img/weapons/myrmecoph_flip.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/myrmecoph_flip.png")
modApi:appendAsset("img/units/mission/myrmecophpuppet.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/units/myrmecophpuppet.png")

local a=ANIMS
a.MyrmecophPuppet =a.MechUnit:new{Image="units/player/myrmecophpuppet.png", PosX = -25, PosY = -9}
a.MyrmecophPuppeta = a.MechUnit:new{Image="units/player/myrmecophpuppet_a.png",  PosX = -25, PosY = -9, NumFrames = 4 }
a.MyrmecophPuppetw = a.MechUnit:new{Image="units/player/myrmecophpuppet_w.png", -25, PosY = -4}
a.MyrmecophPuppet_broken = a.MechUnit:new{Image="units/player/myrmecophpuppet_broken.png", PosX = -25, PosY = -9 }
a.MyrmecophPuppetw_broken = a.MechUnit:new{Image="units/player/myrmecophpuppet_w_broken.png", PosX = -25, PosY = -4 }
a.MyrmecophPuppet_ns = a.MechIcon:new{Image="units/player/myrmecophpuppet_ns.png"}

MyrmecophPuppet = Pawn:new{
    Name = "Myrmecoph Puppet",
    Class = "",
    Health = 2,
    MoveSpeed = 3,
    Massive = true,
    Armor = true,
    Corpse = true,
    Image = "MyrmecophPuppet",
    ImageOffset = 14,
    SkillList = {"MyrmecophControl","MyrmecophControlFlip"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("MyrmecophPuppet")

MyrmecophControl = Science_TC_Control:new{
	Class = "",
	Name = "Pheromonal Control",
	Description = "Briefly control a target Vek, boosting its next attack.",
	Icon = "weapons/myrmecoph_noflip.png",
	LaunchSound = "/weapons/control_enrage",
	ImpactSound = "/impact/generic/control",
	MoveDistance = 2,
	PowerCost = 0,
	Damage = 0,
	Range = 1,
	TwoClickError = "Science_TC_Control_Error",
	TwoClick = true,
	TipImage = {
		Unit = Point(2,3),
		Target = Point(2,2),
		Enemy = Point(2,2),
		Second_Click = Point(3,1),
	},
}

function MyrmecophControl:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local damage = SpaceDamage(p2,0)
	--damage.sScript = "Board:GetPawn("..p:GetString().."):SetBoosted(true)"
	if Board:IsPawnSpace(p2) then
		damage.sImageMark = "combat/icons/icon_mind_glow.png"
	else
		damage.sImageMark = "combat/icons/icon_mind_off_glow.png"
	end
	ret:AddDamage(damage)
	return ret
end

function MyrmecophControl:GetFinalEffect(p1,p2,p3)
	local ret = SkillEffect()
	local target_pawn = Board:GetPawn(p2)
	local boost = SpaceDamage(p3,0)
	
	if target_pawn:IsJumper() then
		ret:AddLeap(Board:GetPath(p2, p3, target_pawn:GetPathProf()),FULL_DELAY)
	elseif target_pawn:IsBurrower() then
		ret:AddBurrow(Board:GetPath(p2, p3, target_pawn:GetPathProf()),FULL_DELAY)
	else
		ret:AddMove(Board:GetPath(p2, p3, target_pawn:GetPathProf()), FULL_DELAY)
	end

	boost.sScript = "Board:GetPawn("..p3:GetString().."):SetBoosted(true)"
	ret:AddDamage(boost)
	
	return ret
end

MyrmecophControlFlip = Science_TC_Control:new{
	Class = "",
	Name = "Pheromonal Beserk",
	Description = "Briefly control a target Vek, flipping and boosting its next attack.",
	Icon = "weapons/myrmecoph_flip.png",
	LaunchSound = "/weapons/control_enrage",
	ImpactSound = "/impact/generic/control",
	MoveDistance = 2,
	PowerCost = 0,
	Damage = 0,
	Range = 1,
	TwoClickError = "Science_TC_Control_Error",
	TwoClick = true,
	TipImage = {
		Unit = Point(2,3),
		Target = Point(2,2),
		Enemy = Point(2,2),
		Second_Click = Point(3,1),
	},
}

function MyrmecophControlFlip:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local damage = SpaceDamage(p2,0)
	if Board:IsPawnSpace(p2) then
		damage.sImageMark = "combat/icons/icon_mind_glow.png"
	else
		damage.sImageMark = "combat/icons/icon_mind_off_glow.png"
	end

	ret:AddDamage(damage)
	return ret
end

function MyrmecophControlFlip:GetFinalEffect(p1,p2,p3)
	local ret = SkillEffect()
	local target_pawn = Board:GetPawn(p2)
	local push_damage = 1 and DIR_FLIP
	local damage = SpaceDamage(p3,0,push_damage)
	local boost = SpaceDamage(p3,0)
	
	if target_pawn:IsJumper() then
		ret:AddLeap(Board:GetPath(p2, p3, target_pawn:GetPathProf()),FULL_DELAY)
	elseif target_pawn:IsBurrower() then
		ret:AddBurrow(Board:GetPath(p2, p3, target_pawn:GetPathProf()),FULL_DELAY)
	else
		ret:AddMove(Board:GetPath(p2, p3, target_pawn:GetPathProf()), FULL_DELAY)
	end

	ret:AddDamage(damage)
	boost.sScript = "Board:GetPawn("..p3:GetString().."):SetBoosted(true)"
	ret:AddDamage(boost)
	
	return ret
end

