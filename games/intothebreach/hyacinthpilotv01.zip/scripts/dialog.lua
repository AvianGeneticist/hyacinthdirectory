-- General Personality: Very motherly, often referring to the other pilots or even the commander as "her dears". Has deep-seeded trauma about losing their children and others they've sworn to taken care of. Constantly refers to their various types of puppets.
-- Adds a personality without the use of a csv file.
-- Table of responses to various triggers.
return {
	-- Game States
	Gamestart = {"We've another chance, my dears. Let's not put it to waste."},
	-- Gamestart_PostVictory = {},
	Death_Revived = {"Ah, was... Was I asleep for a time? I'm sorry, my dears. Let's continue.", "Goodness, what an awful nightmare... Let's ensure it never comes to pass."},
	Death_Main = {"Don't... Don't worry about me, dears. Be good, won't you?"},
	Death_Response = {"No, no! I can't lose more!... Not again..."},
	Death_Response_AI = {"Rest well, dear... We will tend to you when the coast is clear, I promise.", "Shhh... Shh... They can't hurt you anymore."},
	TimeTravel_Win = {"This is it... Be well in your new lives, my dears!"},
	Gameover_Start = {"The power grid! There's nothing keeping the Vek at bay!","I'm sorry, my dears... I failed you."},
	Gameover_Response = {"Everyone, we have to leave... I'm sorry for all we must leave behind."},
	
	-- UI Barks
	Upgrade_PowerWeapon = {"Oh, a gift for me? You shouldn't have, dear.","What an impressive piece of equipment... Perhaps my Serfs could build such a thing."},
	Upgrade_NoWeapon = {"Oh, do you want me to be on body-block duty, dear?","I'm afraid I'm not quite 'clubbing Vek bare-maced' big, dear.",},
	Upgrade_PowerGeneric = {"A little touch-up here and there and you'll be better than ever, dear.","Does that feel better? Mother found you a treat, dear.",},
	
	-- Mid-Battle
	MissionStart = {"Goodness, me... And I thought I was on the large side.","We've many lives to save, my dears! Don't be discouraged."},
	Mission_ResetTurn = {"I can still see... Oh, there it goes.","Goodness, that's not good for the aches and pains...","Even my Totems can't muster time changes like this..."},
	MissionEnd_Dead = {"Be lively, my dears! Not a Vek in sight","Bit by bit, we make the world a better place."},
	MissionEnd_Retreat = {"Such a ruckus when they decide to leave...","Oh, perhaps a Cambrian would be able to fill in the cracks and holes, now."},

	MissionFinal_Start = {"We're quite far from home, aren't we, my dears?",},
	MissionFinal_StartResponse = {"Oh, I see! Even the power grid needs reconciling, sometimes."},
	MissionFinal_FallStart = {"Oh, my, what a tremor... I don't remember bringing a Perditioner with me,"},
	MissionFinal_FallResponse = {"Hold on, everyone! This might be a long trip!"},
	--MissionFinal_Pylons = {},
	MissionFinal_Bomb = {"I don't think we have the equinepower to bring this all down ourselves, dear."},
	--MissionFinal_BombResponse = {},
	MissionFinal_CaveStart = {"I will protect the bomb as if it were one of my children."},
	--MissionFinal_BombDestroyed = {},
	MissionFinal_BombArmed = {"It's ready to blow, my dears! I think this is what we've all been waiting for!"},

	PodIncoming = {"Oh, what's that up above?","Eyes up, my dears! We've a gift from above!"},
	PodResponse = {"It would be a shame to let a gift go to waste, wouldn't it?"},
	PodCollected_Self = {"I've got it good and firm, my dears!","I'll take good care of our little present, I promise."},
	PodDestroyed_Obs = {"Oh, dear... I hope nothing important was inside."},
	Secret_DeviceSeen_Mountain = {"What did you find, there, dear?",},
	Secret_DeviceSeen_Ice = {"Look down there, dear. There's something scintillating under the waves.",},
	Secret_DeviceUsed = {"Oh, that signal... I haven't felt those parts in ages.",},
	Secret_Arriving = {"Heads up, my dears!",},
	Emerge_Detected = {"Watch your hoofing, everyone! They're creeping below.","They certainly don't have respect for good land, do they?"},
	Emerge_Success = {"Oh, to see such good farmland be butchered in such a manner..."},
	Emerge_FailedMech = {"We don't need any more pests on the farm!","A bit jostled around, but I'm still here, dear!"},
	Emerge_FailedVek = {"I must admit, it's a bit cathartic to see something else shambling uneasily for a change."},

	-- Mech State
	Mech_LowHealth = {"The aches and pains come for everything, don't they?","It's a bit draftier than I think it should be in here, dear."},
	Mech_Webbed = {"I'm not going anywhere like this, dear!"},
	Mech_Shielded = {"Everyone loves feeling safe, don't they, dear?","I'll have to make sure my Deltas are doing well after this..."},
	Mech_Repaired = {"Just let mother take care of you, dear.","There you are, dear. Does that feel better?"},
	Pilot_Level_Self = {"Everything feels just a bit clearer, now...",},
	Pilot_Level_Obs = {"Look at you, #main_reverse! I'm so proud..."},
	Mech_ShieldDown = {"Easy come, easy go...","Nothing lasts forever, I suppose.",},

	-- Damage Done
	Vek_Drown = {"I suppose I can empathize... I was never a good swimmer.","Oh, my... That's not a simple irrigation ditch, is it?"},
	Vek_Fall = {"Oh, my... I don't think it's coming back up, dear."},
	Vek_Smoke = {"Another one down, dear!","Reminds me of some other bugs I know..."},
	Vek_Frozen = {"Perhaps some time to stop and think will be good for it.","I must admit, they make rather beautiful ice sculptures.",},
	VekKilled_Self = {"Another one down, dear!","Reminds me of some other bugs I know..."},
	VekKilled_Obs = {"Good work, dear! I'm very proud.",},
	VekKilled_Vek = {"Oh, dear... I'm glad my children are good at avoiding infighting."},

	DoubleVekKill_Self = {"Sometimes I scare myself with just how easily violence comes...","My Praetors would be proud, were they here."},
	DoubleVekKill_Obs = {"Outstanding work, dear!",},
	DoubleVekKill_Vek = {"It seems their ruthlessness extends to their own kin."},

	MntDestroyed_Self = {"Blowing off steam feels much better when you know what you're striking doesn't feel a thing.","Down it goes! It makes a lovely cobblestone walkway, doesn't it?"},
	MntDestroyed_Obs = {"Blowing off steam feels much better when you know what you're striking doesn't feel a thing, hm?","Down it goes! It makes a lovely cobblestone walkway, doesn't it?"},
	MntDestroyed_Vek = {"Down it goes! It makes a lovely cobblestone walkway, doesn't it?"},

	PowerCritical = {"Be careful, everyone! I'm not sure how much more the grid can take!"},
	Bldg_Destroyed_Self = {"No! I... I don't know what came over me."},
	Bldg_Destroyed_Obs = {"Be careful, dear! Those buildings aren't meant for beating on!"},
	Bldg_Destroyed_Vek = {"We won't forgive the Vek for this","Ah! No! We couldn't protect all of them..."},
	Bldg_Resisted = {"I'm glad to see my children had a chance to help with fortifying.","That was close! Be careful, everyone!"},


	-- Shared Missions
	Mission_Train_TrainStopped = {"It's not moving, but I can still see lights. Keep the train safe, my dears!"},
	Mission_Train_TrainDestroyed = {"No! We couldn't protect it..."},
	Mission_Block_Reminder = {"The land can only take so much punishment, my dears! Keep the Vek underground!"},

	-- Archive
	Mission_Airstrike_Incoming = {"I remember my Imps and Howitzers trying a similar technique, once...","Heads down, everyone!"},
	Mission_Tanks_Activated = {"Oh, wonderful! They're both up and running!"},
	Mission_Tanks_PartialActivated = {"We couldn't save both of them, but one of them is present and accounted for."},
	Mission_Dam_Reminder = {"Remember we need to knock that dam down, dear!"},
	Mission_Dam_Destroyed = {"Irrigation is always important, dear.","Oh, it reminds me of the farm...",},
	Mission_Satellite_Destroyed = {"Well, it was unoccupied, at least... We shouldn't let the other be destroyed, my dears."},
	Mission_Satellite_Imminent = {"It's about to take off! Get clear of the blast zone, my dears!"},
	Mission_Satellite_Launch = {"I feel an odd sense of familiarity, watching it soar into space..."},
	Mission_Mines_Vek = {"My Envoys would be proud to see landmines hard at work."},

	-- RST
	Mission_Terraform_Destroyed = {"My Envoys would be proud to see landmines hard at work."},
	Mission_Terraform_Attacks = {"I can't say I understand the rationale for terraforming land for the worse...","When this is all over, remind me to send a Cambrian to help with the reclamation."},
	Mission_Cataclysm_Falling = {"Watch your step, dear! That last one's a lulu!",},
	Mission_Lightning_Strike_Vek = {"I've always found lightning rather beautiful...","My Arrays and Agents would love frolicking in this storm.","I'll have to bring my Consuls here for a sabbatical, sometime."},
	Mission_Solar_Destroyed = {"I don't think a solar panel can collect much energy like that, dear!"},
	Mission_Force_Reminder = {"I know earthshaping's not our specialty, but we still have mountains to remove, dear."},

	-- Pinnacle
	Mission_Freeze_Mines_Vek = {"I must admit, I'm used to mines being much hotter","My goodness, it certainly froze up in a hurry!"},
	Mission_Factory_Destroyed = {"For better or worse, that facility is gone","My Anchorages would weep at the loss of such a prizeable building..."},
	Mission_Factory_Spawning = {"Those don't look like my Sovereignties, dears; be careful!","They look so confused... Perhaps we could just subdue them gently?"},
	Mission_Reactivation_Thawed = {"They've warmed up, but not to us, dears!"},
	Mission_SnowStorm_FrozenVek = {"Such frosty weather reminds me of my Totems...","Such frosty weather reminds me of home...",},
	Mission_SnowStorm_FrozenMech = {"Brrr! I'm alright in here, dear, but I'm not going anywhere!"},
	BotKilled_Self = {"I'm sorry, young one... At least you can rest now.","Shhh... It's okay. You can rest in peace, now."},
	--BotKilled_Obs = {},

	-- Detritus
	Mission_Disposal_Destroyed = {"Ah! We needed that, didn't we, dear?"},
	Mission_Disposal_Activated = {"That seems a bit excessive for simple disposal, doesn't it?","My Pustules would love to wash themselves in those puddles..."},
	Mission_Barrels_Destroyed = {"Even the ground beneath gets washed away...","My Pustules would love to go for a dip in that new lake."},
	Mission_Power_Destroyed = {"Ah! That plant isn't going to be generating anything anymore."},
	Mission_Teleporter_Mech = {"Hm? Oh, goodness... Took this old brain a couple moments to catch up.",},
	Mission_Belt_Mech = {"Oh, well, this is almost rather fun, isn't it?"},
}