local description = "This mod adds a handful of squads based around Hyacinth's puppets."

local mod = {
    id = "Zoura3025_HyacinthMod",
    name = "Hyacinth's Legion",
    version = "0.1",
    dependencies = {
        memedit = "1.1.5",
    },
    modApiVersion = "2.9.2",
    gameVersion = "1.2.88",
    icon = "img/mod_icon.png",
    description = description,
}

function mod:init()
    modApi:addWeapon_Texts(require(self.scriptPath.."weapon_text"))
    require(self.scriptPath.."freeaim_base")
    require(self.scriptPath.."weapons")
    require(self.scriptPath.."pawns")
    require(self.scriptPath.."weapon_text")
end


function mod:load(options, version)

modApi:addSquad(
    {
     "Hyacinth's First",     -- title
     "ManipulatorPuppet",              -- mech #1
     "TricksterPuppet",          -- mech #2
     "ReconcilantPuppet",              -- mech #3
     id="HyacinthSquad_0"
    },
    "Hyacinth's First",
    "Hyacinth's first three types of spawn. Has a wide variety of physical, magical, and psionic options.",
    self.resourcePath .."img/mod_icon.png"
)

modApi:addSquad(
    {
     "Hyacinth's Analogues",     -- title
     "AnchoragePuppet",              -- mech #1
     "FederationAnalogue",          -- mech #2
     "SovereigntyAnalogue",              -- mech #3
     id="HyacinthSquad_1"
    },
    "Hyacinth's Analogues",
    "An Anchorage Puppet and its assembled subpuppets and Analogues. Heavily reliant on on-site repairs and boosts.",
    self.resourcePath .."img/mod_icon.png"
)

end


return mod
