local mod = modApi:getCurrentMod()
local path = mod_loader.mods[modApi.currentMod].resourcePath
local weaponPath = path .."img/weapons/"
modApi:appendAsset("img/weapons/fireball.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/fireball.png")
modApi:appendAsset("img/weapons/frostray.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/frostray.png")

modApi:appendAsset("img/weapons/healingenergy.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/healingenergy.png")
modApi:appendAsset("img/weapons/impspawn.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/impspawn.png")
modApi:appendAsset("img/weapons/divestrike.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/divestrike.png")

modApi:appendAsset("img/weapons/manipulatorstrike.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/manipulatorstrike.png")

modApi:appendAsset("img/weapons/howitzershelling.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/howitzershelling.png")
modApi:appendAsset("img/weapons/heraldspawn.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/heraldspawn.png")
modApi:appendAsset("img/weapons/heraldsneeze.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/heraldsneeze.png")

modApi:appendAsset("img/weapons/anchoragebeam.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/anchoragebeam.png")
modApi:appendAsset("img/weapons/anchorage_mixedspawn.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/anchorage_mixedspawn.png")
modApi:appendAsset("img/weapons/middleweightshove.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/middleweightshove.png")
modApi:appendAsset("img/weapons/colonyconstruct.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/colonyconstruct.png")
modApi:appendAsset("img/weapons/colonybard.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/colonybard.png")
modApi:appendAsset("img/weapons/colonybeam.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/colonybeam.png")
modApi:appendAsset("img/weapons/serf_pilum.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/serf_pilum.png")
modApi:appendAsset("img/weapons/serf_firstaid.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/serf_firstaid.png")

modApi:appendAsset("img/weapons/sovereignty_machinegun.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/sovereignty_machinegun.png")
modApi:appendAsset("img/weapons/sovereignty_magicmissile.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/sovereignty_magicmissile.png")

modApi:appendAsset("img/weapons/heavyweightshove.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/heavyweightshove.png")
modApi:appendAsset("img/weapons/provincespawn.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/provincespawn.png")
modApi:appendAsset("img/weapons/downshot.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/downshot.png")
modApi:appendAsset("img/weapons/bustermissile.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/weapons/bustermissile.png")

modApi:appendAsset("img/effects/shotup_imp.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/shotup_imp.png")
modApi:appendAsset("img/effects/shotup_serf.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/shotup_serf.png")
modApi:appendAsset("img/effects/shotup_province.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/shotup_province.png")
modApi:appendAsset("img/effects/shotup_herald.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/shotup_herald.png")
modApi:appendAsset("img/effects/shotup_pupa.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/shotup_pupa.png")
modApi:appendAsset("img/effects/shotup_magicmissile.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/shotup_magicmissile.png")
modApi:appendAsset("img/effects/shot_serfpilum_U.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/shot_serfpilum_U.png")
modApi:appendAsset("img/effects/shot_serfpilum_R.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/shot_serfpilum_R.png")
modApi:appendAsset("img/effects/shot_bustermissile_U.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/shot_bustermissile_U.png")
modApi:appendAsset("img/effects/shot_bustermissile_R.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/shot_bustermissile_R.png")

modApi:appendAsset("img/effects/bulletbarrage.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/effects/bulletbarrage.png")

modApi:appendAsset("img/combat/icons/icon_addemplacement.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/combat/icons/icon_addemplacement.png")
modApi:appendAsset("img/combat/icons/icon_addfoundry.png", mod_loader.mods[modApi.currentMod].resourcePath.."img/combat/icons/icon_addfoundry.png")
Location["combat/icons/icon_addemplacement.png"] = Point(-16, 0)
Location["combat/icons/icon_addfoundry.png"] = Point(-16, 0)

local effects = {
    "laseranch_hit.png",
    "laseranch_R.png",
    "laseranch_R1.png",
    "laseranch_R2.png",
    "laseranch_start.png",
    "laseranch_U1.png",
    "laseranch_U2.png",
}
for _, effect in ipairs(effects) do
    modApi:appendAsset("img/effects/".. effect, mod_loader.mods[modApi.currentMod].resourcePath .. "img/effects/" .. effect)
    Location["effects/"..effect] = Point(-12,3)
end

ANIMS.BulletBarrage = Animation:new{
	Image = "effects/bulletbarrage.png",
	NumFrames = 15,
	Time = 0.04,
	
	PosX = -20,
	PosY = -0
}

Prime_Manipulator = Skill:new{
	Range = RANGE_PROJECTILE,
	PathSize = INT_MAX,
	Name = "Manipulative Strike",
	Description = "Damage and push the target; shields self in melee, does extra damage at range.",
	Icon = "weapons/manipulatorstrike.png",
	Explo = "explopush1_",
	Class = "Prime",
	Damage = 1,
	MaxDamage = 2,
	MeleeRepair = 0,
	RangedDamage = 1,
	PushBack = 0,
	BackShot = 0,
	ProjectileArt = "effects/shot_mechtank",
	Push = 1,
	Freeze = 0,
	Acid = 0,
	Flip = 0,
	Fire = 0,
	Shield = 0,
	Upgrades = 2,
	UpgradeCost = {1,2},
	MeleeShield = true,
	Phase = false,
	PhaseShield = false,
	ZoneTargeting = ZONE_DIR,
	TipImage = {
		Unit = Point(3,3),
		Enemy = Point(3,2),
		Enemy2 = Point(1,3),
		Target = Point(1,3),
		Second_Target = Point(3,2),
		Second_Origin = Point(3,3),
	},
}

Prime_Manipulator_A = Prime_Manipulator:new{
		UpgradeDescription = "Melee Manipulative Strikes repair 1 HP. Ranged Manipulative Strikes do 1 extra damage.",
		RangedDamage = 2,
		MeleeRepair = -1,
}
Prime_Manipulator_B = Prime_Manipulator:new{
		UpgradeDescription = "Increases the damage of the Manipulative Strike",
		Damage = 2,
}
Prime_Manipulator_AB = Prime_Manipulator:new{
		Damage = 2,
		RangedDamage = 2,
		MeleeRepair = -1,
}

function Prime_Manipulator:GetTargetArea(p1)

	if not self.Phase then
		return Board:GetSimpleReachable(p1, self.PathSize, self.CornersAllowed)
	else
		local ret = PointList()
	
		for dir = DIR_START, DIR_END do
			for i = 1, 8 do
				local curr = Point(p1 + DIR_VECTORS[dir] * i)
				if not Board:IsValid(curr) then
					break
				end
				
				ret:push_back(curr)
				
				if Board:IsBlocked(curr,PATH_PHASING) then
					break
				end
			end
		end
	
	return ret
	
	end
end

function Prime_Manipulator:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)

	if self.PushBack == 1 then
		local selfDam = SpaceDamage(p1, self.SelfDamage, GetDirection(p1 - p2))
		ret:AddDamage(selfDam)
	end

	local pathing = self.Phase and PATH_PHASING or PATH_PROJECTILE
	local target = GetProjectileEnd(p1,p2,pathing)  
	
	local damage = SpaceDamage(target, self.Damage + self.RangedDamage)
	if self.Flip == 1 then
		damage = SpaceDamage(target,self.Damage,DIR_FLIP)
	end

	for i = DIR_START, DIR_END do
	  local curr = GetProjectileEnd(p1,p2,pathing) + DIR_VECTORS[i]
	  if curr == p1 then
			local shield = SpaceDamage(p1,self.MeleeRepair)
			shield.iShield = 1
			ret:AddDamage(shield)
			damage = SpaceDamage(target, self.Damage)
		end
	end
	
	if self.Phase and Board:IsBuilding(target) then
		damage.sAnimation = ""
		damage.iDamage = 0
	end
	if self.Push == 1 then
		damage.iPush = direction
	end
	damage.iAcid = self.Acid
	damage.iFrozen = self.Freeze
	damage.iFire = self.Fire
	damage.iShield = self.Shield
	damage.sAnimation = self.Explo..direction
	
	ret:AddProjectile(damage, self.ProjectileArt, NO_DELAY)--"effects/shot_mechtank")
		
	if self.BackShot == 1 then
		local backdir = GetDirection(p1 - p2)
		local target2 = GetProjectileEnd(p1,p1 + DIR_VECTORS[backdir])

		if target2 ~= p1 then
			damage = SpaceDamage(target2, self.Damage, backdir)
			damage.sAnimation = self.Explo..backdir
			ret:AddProjectile(damage,self.ProjectileArt)
		end
	end

	
	if self.PhaseShield then
		local temp = p1 + DIR_VECTORS[direction]
		while true do
			if Board:IsBuilding(temp) then
				damage = SpaceDamage(temp, 0)
				damage.iShield = 1
				ret:AddDamage(damage)
			end
		
			if temp == target then
				break
			end
			
			temp = temp + DIR_VECTORS[direction]
		end
	end
	
	return ret
end

Ranged_TricksterPuppetBolt = ArtilleryDefault:new{
	Name = "Fireball",
	Description = "Damages an area and enflames the target tile.",
	Class = "Ranged",
	Icon = "weapons/fireball.png",
	UpShot = "effects/shotup_fireball.png",
	ArtilleryStart = 2,
	ArtillerySize = 8,
	BuildingDamage = true,
	Push = 0,
	DamageOuter = 1,
	DamageCenter = 1,
	WideFire = false,
	PowerCost = 0, --AE Change
	Damage = 1,---USED FOR TOOLTIPS
	BounceAmount = 1,
	Explosion = "",
	ExplosionCenter = "ExploArt1",
	ExplosionOuter = "",
	Upgrades = 2,
	UpgradeCost = {1,3},
	LaunchSound = "/weapons/artillery_volley",
	ImpactSound = "/impact/generic/explosion",
	TipImage = {
		Unit = Point(2,0),
		Enemy = Point(2,3),
		Enemy2 = Point(3,3),
		Enemy3 = Point(1,3),
		Enemy4 = Point(2,2),
		Building = Point(2,4),
		Target = Point(2,3),
	},
}


Ranged_TricksterPuppetBolt_A = Ranged_TricksterPuppetBolt:new{
		UpgradeDescription = "Prevents damage to buildings.",
		BuildingDamage = false,
}

Ranged_TricksterPuppetBolt_B = Ranged_TricksterPuppetBolt:new{
		UpgradeDescription = "Increases damage, particularly in the center.",
		DamageOuter = 2,
		DamageCenter = 3,
}

Ranged_TricksterPuppetBolt_AB = Ranged_TricksterPuppetBolt:new{
		DamageOuter = 2,
		DamageCenter = 3,
		BuildingDamage = false,
}

function Ranged_TricksterPuppetBolt:GetSkillEffect(p1, p2)	
	local ret = SkillEffect()
	
	local damage = SpaceDamage(p2,self.DamageCenter)
	damage.iFire = 1
	damage.sAnimation = self.ExplosionCenter
	
	if not self.BuildingDamage and Board:IsBuilding(p2) then		-- Target Buildings - 
		damage.iDamage = DAMAGE_ZERO
	end
	
	ret:AddBounce(p1, 1)
	ret:AddArtillery(damage, self.UpShot)
	
	if self.BounceAmount ~= 0 then	ret:AddBounce(p2, self.BounceAmount) end
	
	for dir = 0, 3 do
		damage = SpaceDamage(p2 + DIR_VECTORS[dir],  self.DamageOuter)
		
		if self.Push == 1 then
			damage.iPush = dir
		end
		damage.sAnimation = self.OuterAnimation..dir
		
		if not self.BuildingDamage and Board:IsBuilding(p2 + DIR_VECTORS[dir]) then	
			damage.iDamage = 0
			damage.sAnimation = "airpush_"..dir
		end
		
		ret:AddDamage(damage)
		if self.BounceOuterAmount ~= 0 then	ret:AddBounce(p2 + DIR_VECTORS[dir], self.BounceOuterAmount) end  
	end

	return ret
end

Ranged_TricksterFrostBeam = LaserDefault:new{
	Name = "Frost Ray",
	Description = "A ray of damaging frost that protects buildings with ice.",
	Icon = "weapons/frostray.png",
	Class = "Ranged",
	Damage = 2,
	MinDamage = 2,
	Limited = 2,
	PowerCost = 0,
	Smoke = 0,
	Acid = 0,
	Fire = 0,
	Freeze = 0,
	Upgrades = 2,
	UpgradeCost = {1,2},
	FriendlyDamage = true,
	LaserAnimation = "ExploAir1",
	LaserArt = "effects/laser_freeze",
	LaunchSound = "/weapons/burst_beam",
	TipImage = {
		Unit = Point(2,5),
		Enemy = Point(2,4),
		Building = Point(2,3),
		Enemy2 = Point(2,2),
		Friendly = Point(2,1),
		Enemy3 = Point(2,0),
		Target = Point(2,4),
	},
}

Ranged_TricksterFrostBeam_A = Ranged_TricksterFrostBeam:new{
		UpgradeDescription = "Increases maximum number of uses by 1.",
		Limited = 3,
}

Ranged_TricksterFrostBeam_B = Ranged_TricksterFrostBeam:new{
		UpgradeDescription = "Striking allies deals no damage and increases beam damage by 1.",
		FriendlyDamage = false,
}

Ranged_TricksterFrostBeam_AB = Ranged_TricksterFrostBeam:new{
		Limited = 3,
		FriendlyDamage = false,
}

function Ranged_TricksterFrostBeam:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)
	local point = p1 + DIR_VECTORS[direction]
	local damage = self.Damage
	local minDamage = self.MinDamage or 1
	local start = point - DIR_VECTORS[direction]
	
	if forced_end ~= nil then
		LOG("Forced end = "..forced_end:GetString())
	else
		LOG("No forced end!")
	end
	ret:AddBounce(p1,2)
	while Board:IsValid(point) do
	
		local temp_damage = damage  --This is so that if damage is set to 0 because of an ally, it doesn't affect the damage calculation of the laser.
		
		if not self.FriendlyDamage and Board:IsPawnTeam(point, TEAM_PLAYER) then
			damage = damage + 3
			temp_damage = DAMAGE_ZERO
		end

		if Board:IsBuilding(point) then
			temp_damage = DAMAGE_ZERO
		end

		local dam = SpaceDamage(point, temp_damage)
		
		dam.iSmoke = self.Smoke
		dam.iAcid = self.Acid
		dam.iFire = self.Fire
		dam.iFrozen = self.Freeze

		if Board:IsBuilding(point) then
			dam.iFrozen = 1
		end
		
		-- if it's the end of the line (ha), add the laser art -- not pretty
		if forced_end == point or Board:GetTerrain(point) == TERRAIN_MOUNTAIN or not Board:IsValid(point + DIR_VECTORS[direction]) then
			if queued then 
				ret:AddQueuedProjectile(dam,self.LaserArt)
			else
				ret:AddProjectile(start,dam,self.LaserArt,FULL_DELAY)
			end
			break
		else
			if queued then
				ret:AddQueuedDamage(dam)  
			else
				ret:AddDamage(dam)   --JUSTIN TEST
			end
		end
		
		damage = damage - 1
		if damage < minDamage then damage = minDamage end
					
		point = point + DIR_VECTORS[direction]	
	end
	
	
	return ret
end

--- RECONCILANT SKILLS

Heal_ReconcilantPuppet = Skill:new{	
	Name = "Healing Energy",
	Description = "Recovers 2 Health to the target, removing Fire and A.C.I.D.",
	Icon = "weapons/healingenergy.png",
	Class = "Science",
	Amount = -2,
	AreaHeal = false,
	ArtillerySize = 3,
	Upgrades = 1,
	UpgradeCost = {2},
	TipImage = {
		Unit_Damaged = Point(2,0),
		Mountain = Point(2,1),
		Friendly_Damaged = Point(2,3),
		Friendly_Damaged2 = Point(3,3),
		Friendly_Damaged3 = Point(1,3),
		Target = Point(2,3),
	},
}

Heal_ReconcilantPuppet_A = Heal_ReconcilantPuppet:new{	
	UpgradeDescription = "Increases max range by 2 and affects an area.",
	Amount = -2,
	AreaHeal = true,
	ArtillerySize = 5,
}

function Heal_ReconcilantPuppet:GetTargetArea(point)
	local ret = PointList()
	
	for dir = DIR_START, DIR_END do
		for i = 1, self.ArtillerySize do
			local curr = Point(point + DIR_VECTORS[dir] * i)
			if not Board:IsValid(curr) then
				break
			end
			
			if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
				ret:push_back(curr)
			end

		end
	end
	
	return ret
end

-- The commented portions of this Skill effect are for an unused Imp Resurrection effect. I'm leaving it here in case I want it for something.
function Heal_ReconcilantPuppet:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local selfdamage = SpaceDamage(p1,self.Amount)
	selfdamage.iFire = EFFECT_REMOVE
	selfdamage.iAcid = EFFECT_REMOVE
	local damage = SpaceDamage(p2,self.Amount)
	damage.iFire = EFFECT_REMOVE
	damage.iAcid = EFFECT_REMOVE

--	if Board:GetPawn(p2) ~= nil then
--		if Board:GetPawn(p2):GetType() == "Deploy_ImpPuppet" and Board:GetPawn(p2):GetHealth() == 0 then
--			ret:AddScript("Board:GetPawn("..p2:GetString().."):SetHealth(2)")
--		end
--	end

	if self.AreaHeal then
		for dir = 0, 3 do
			local damagearea = SpaceDamage(p2 + DIR_VECTORS[dir],  self.Amount)
			damagearea.iFire = EFFECT_REMOVE
			damagearea.iAcid = EFFECT_REMOVE
			ret:AddDamage(damagearea)
--			if Board:GetPawn(p2 + DIR_VECTORS[dir]) ~= nil then
--				if Board:GetPawn(p2 + DIR_VECTORS[dir]):GetType() == "Deploy_ImpPuppet" and Board:GetPawn(p2 + DIR_VECTORS[dir]):GetHealth() == 0 then
--					ret:AddScript("Board:GetPawn("..(p2 + DIR_VECTORS[dir]):GetString().."):SetHealth(2)")
--				end
--			end
		end
	end
	
	ret:AddDamage(selfdamage)
	ret:AddDamage(damage)
	
	return ret
end

Deploy_ImpPuppet = Pawn:new{
	Name = "Imp Puppet",
	Health = 1,
	MoveSpeed = 4,
	Flying = true,
    Image = "ImpPuppet",
--    ImageOffset = 14, (Switched to preset colours in v0.2 to avoid a bug)
	SkillList = { "Deploy_ImpStrike" },
	--SoundLocation = "/support/civilian_tank/", -- not implemented
	SoundLocation = "/mech/brute/tank",
	DefaultTeam = TEAM_PLAYER,
	ImpactMaterial = IMPACT_METAL,
	Corpse = true,
	--Corporate = true
}

Deploy_ImpPuppetA = Deploy_ImpPuppet:new{Health = 2, SkillList = {"Deploy_ImpStrike2"}}

Deploy_ImpStrike = Prime_Punchmech:new{  
	Class = "",
	Name = "Divestrike",
	Description = "Dash to a nearby tile, damaging and pushing whatever is on it.",
	Icon = "weapons/divestrike.png",
	Rarity = 0,
	Explosion = "",
	LaunchSound = "/weapons/titan_fist",
	Range = 2, -- Tooltip?
	PathSize = 3,
	Damage = 1,
	Upgrades = 0,
	PushBack = false,
	Flip = false,
	Dash = true,
	Shield = false,
	Projectile = false,
	Push = 1, --Mostly for tooltip, but you could turn it off for some unknown reason
	TipImage = {
		Unit = Point(2,1),
		Target = Point(2,3),
		Enemy = Point(2,3),
		CustomPawn = "Deploy_ImpPuppet",
	},
}

Deploy_ImpStrike2 = Deploy_ImpStrike:new{  
	Class = "",
	Name = "Divestrike",
	Description = "Dash to a nearby tile, damaging and pushing whatever is on it.",
	Icon = "weapons/divestrike.png",
	Rarity = 0,
	Explosion = "",
	LaunchSound = "/weapons/titan_fist",
	Range = 3, -- Tooltip?
	PathSize = 4,
	Damage = 2,
	Upgrades = 0,
	PushBack = false,
	Flip = false,
	Dash = true,
	Shield = false,
	Projectile = false,
	Push = 1, --Mostly for tooltip, but you could turn it off for some unknown reason
	TipImage = {
		Unit = Point(2,1),
		Target = Point(2,3),
		Enemy = Point(2,3),
		CustomPawn = "Deploy_ImpPuppet",
	},
}

function Deploy_ImpStrike:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)

	local doDamage = true
	local target = GetProjectileEnd(p1,p2,PATH_PROJECTILE)
	local push_damage = self.Flip and DIR_FLIP or direction
	local damage = SpaceDamage(target, self.Damage, push_damage)
	damage.sAnimation = "explopunch1_"..direction
	if self.Flip then damage.sAnimation = "SwipeClaw2" end  -- Change the animation if it's a flip
    
	if self.Shield then
		local shield = SpaceDamage(p1,0)
		shield.iShield = EFFECT_CREATE
		ret:AddDamage(shield)
	end
	
    if self.Dash then
       
        if not Board:IsBlocked(target,PATH_PROJECTILE) then -- dont attack an empty edge square, just run to the edge
	    	doDamage = false
		    target = target + DIR_VECTORS[direction]
    	end
    	
    	ret:AddCharge(Board:GetSimplePath(p1, p2 - DIR_VECTORS[direction]), FULL_DELAY)
    elseif self.Projectile and target:Manhattan(p1) ~= 1 then
		damage.loc = target
		ret:AddDamage(SpaceDamage(p1,0,(direction+2)%4))
		ret:AddProjectile(damage, "effects/shot_fist")
		doDamage = false--damage covered here
	else
		target = p2
	end

	
	if doDamage then
		damage.loc = p2
		ret:AddMelee(p2 - DIR_VECTORS[direction], damage)
	end
	
	if self.PushBack then
		ret:AddDamage(SpaceDamage(p1, 0, GetDirection(p1 - p2)))
	end
	return ret
end	

DeploySkill_ImpPuppet = Deployable:new{
	Name = "Spawn Imp",
	Description = "Spawn an Imp Puppet to help in combat. Limited uses.",
	Icon = "weapons/impspawn.png",
	Class = "Science",
	Rarity = 1,
	Deployed = "Deploy_ImpPuppet",
	Projectile = "effects/shotup_imp.png",
	Limited = 2,
	Twins = false,
	Upgrades = 2,
	UpgradeCost = {1,2},
	LaunchSound = "/weapons/deploy_tank",
	ImpactSound = "/impact/generic/mech",
	TipImage = {
		Unit = Point(2,3),
		Target = Point(2,1),
		Enemy = Point(4,1),
		Second_Origin = Point(2,1),
		Second_Target = Point(4,1),
	},
}

function DeploySkill_ImpPuppet:GetTargetArea(point)
	local ret = PointList()

	local impPresent = 0
	local pawns = extract_table(Board:GetPawns(TEAM_PLAYER))
	for i, pawn_id in ipairs(pawns) do
		local pawn = Board:GetPawn(Board:GetPawnSpace(pawn_id))
		local t = pawn:GetType()
		if t == "Deploy_ImpPuppet" or t == "Deploy_ImpPuppetA" then
			impPresent = impPresent + 1
		end
	end

	if self.Twins and impPresent == 1 then
		for dir = DIR_START, DIR_END do
			for i = 2, self.ArtillerySize do
				local curr = Point(point + DIR_VECTORS[dir] * i)
				local curr2 = Point(point + DIR_VECTORS[dir] * (i - 1))
				if not Board:IsValid(curr) or not Board:IsValid(curr2) then
					break
				end
				
				if (not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND)) and (not self.OnlyEmpty or not Board:IsBlocked(curr2,PATH_GROUND)) then
					ret:push_back(curr)
				end

			end
		end
	else
		for dir = DIR_START, DIR_END do
			for i = 2, self.ArtillerySize do
				local curr = Point(point + DIR_VECTORS[dir] * i)
				if not Board:IsValid(curr) then
					break
				end
				
				if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
					ret:push_back(curr)
				end

			end
		end
	end
	
	return ret
end

function DeploySkill_ImpPuppet:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local dir = GetDirection(p2 - p1)
	
	local impPresent = 0
	local pawns = extract_table(Board:GetPawns(TEAM_PLAYER))
	for i, pawn_id in ipairs(pawns) do
		local pawn = Board:GetPawn(Board:GetPawnSpace(pawn_id))
		local t = pawn:GetType()
		if t == "Deploy_ImpPuppet" or t == "Deploy_ImpPuppetA" then
			impPresent = impPresent + 1
		end
	end

	if self.Twins and impPresent == 1 then
		local damage = SpaceDamage(p2,0)
		local damage2 = SpaceDamage(p2 - DIR_VECTORS[dir],0)
		damage.sPawn = self.Deployed
		damage2.sPawn = self.Deployed
		ret:AddArtillery(damage,self.Projectile)
		ret:AddArtillery(damage2,self.Projectile)
		return ret
	else
		local damage = SpaceDamage(p2,0)
		damage.sPawn = self.Deployed
		ret:AddArtillery(damage,self.Projectile)
		return ret
	end
end

DeploySkill_ImpPuppet_A = DeploySkill_ImpPuppet:new{
		Deployed = "Deploy_ImpPuppet",
		UpgradeDescription = "Makes the second spawn each mission spawn a second Imp.",
		Twins = true,
		TipImage = {
		Unit = Point(2,3),
		Target = Point(2,1),
		Enemy = Point(4,1),
		Second_Origin = Point(2,1),
		Second_Target = Point(4,1),
	},
}
DeploySkill_ImpPuppet_B = DeploySkill_ImpPuppet:new{
		Deployed = "Deploy_ImpPuppetA",
		UpgradeDescription = "Increases the health and damage of Imps.",
}
DeploySkill_ImpPuppet_AB = DeploySkill_ImpPuppet:new{
		Deployed = "Deploy_ImpPuppetA",
		Twins = true,
}

-- HOWITZER SKILLS

HowitzerShelling = FreeAimArtilleryTwoClick:new{
	Name = "Howitzer Shell",
	Description = "Fires two incendiary shells at targets in a square range.",
	Class = "Ranged",
	Icon = "weapons/howitzershelling.png",
	UpShot = "effects/shotup_pupa.png",
	ArtilleryStart = 2, --This is the inner bounds of the square. 1 = Adjacent tiles
	ArtillerySize = 4, --Determines the outer bounds of the square. 1 = Adjacent tiles
	BuildingDamage = true,
	DamageOuter = 0,
	DamageCenter = 1,
	AcidEnhanced = 1,
	CenterFire = 1,
	Push = 0,
	PowerCost = 0, --AE Change
	Damage = 1,---USED FOR TOOLTIPS
	BounceAmount = 1,
	Upgrades = 2,
	UpgradeCost = {2,2},
	ExplosionCenter = "ExploArt1",
	LaunchSound = "/weapons/artillery_volley",
	ImpactSound = "/impact/generic/explosion",
}

HowitzerShelling_A = HowitzerShelling:new{
	ArtillerySize = 5, --Determines the outer bounds of the square. 1 = Adjacent tiles
	DamageCenter = 2,
	}

HowitzerShelling_B = HowitzerShelling:new{
	AcidEnhanced = 1
	}

HowitzerShelling_AB = HowitzerShelling:new{
	ArtillerySize = 5, --Determines the outer bounds of the square. 1 = Adjacent tiles
	DamageCenter = 2,
	AcidEnhanced = 1
	}

Deploy_HeraldPuppet = Pawn:new{
	Name = "Herald Puppet",
	Health = 2,
	MoveSpeed = 3,
	Massive = true,
    Image = "HeraldPuppet",
    ImageOffset = 14,
	SkillList = { "Deploy_HeraldSneeze" },
	--SoundLocation = "/support/civilian_tank/", -- not implemented
	SoundLocation = "/mech/brute/tank",
	DefaultTeam = TEAM_PLAYER,
	ImpactMaterial = IMPACT_METAL,
	Corpse = true,
	--Corporate = true
}

DeploySkill_HeraldPuppet = Deployable:new{
	Name = "Spawn Herald",
	Description = "Spawn a Herald Puppet to help in combat. Single use.",
	Icon = "weapons/heraldspawn.png",
	Class = "Ranged",
	Rarity = 1,
	Deployed = "Deploy_HeraldPuppet",
	Projectile = "effects/shotup_herald.png",
	Limited = 1,
	Upgrades = 2,
	UpgradeCost = {2,2},
	LaunchSound = "/weapons/deploy_tank",
	ImpactSound = "/impact/generic/mech",
	TipImage = {
		Unit = Point(2,3),
		Target = Point(2,1),
		Enemy = Point(3,1),
		Second_Origin = Point(2,1),
		Second_Target = Point(3,1),
	},
}

DeploySkill_HeraldPuppet_A = DeploySkill_HeraldPuppet:new{
		Deployed = "Deploy_HeraldPuppetA",
		UpgradeDescription = "Increases Herald Sneeze adjacent damage and adds push to far tiles.",
}

DeploySkill_HeraldPuppet_B = DeploySkill_HeraldPuppet:new{
		Deployed = "Deploy_HeraldPuppetB",
		UpgradeDescription = "Increases Herald Health by 2 and Move Range by 1.",
}

DeploySkill_HeraldPuppet_AB = DeploySkill_HeraldPuppet:new{
		Deployed = "Deploy_HeraldPuppetAB",
}

Deploy_HeraldSneeze = Skill:new{  
	Class = "",
	Name = "Corrosive Sneeze",
	Description = "Sneeze in a cone, damaging tiles and acidifying units.",
	Icon = "weapons/heraldsneeze.png",
	Rarity = 0,
	Explosion = "",
	LaunchSound = "/weapons/titan_fist",
	Range = 1, -- Tooltip?
	PathSize = 1,
	Damage = 1,
	MeleeDamage = 0,
	PushBack = false,
	Flip = false,
	Dash = false,
	Shield = false,
	Projectile = false,
	Push = 0, --Mostly for tooltip, but you could turn it off for some unknown reason
	PowerCost = 0, --AE Change
	TipImage = StandardTips.Melee
}

Deploy_HeraldSneeze2 = Deploy_HeraldSneeze:new{
	Description = "Sneeze in a cone, damaging tiles, acidifying units, and pushing far tiles.",
	MeleeDamage = 1,
	Push = 1
}

function Deploy_HeraldSneeze:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)

	--local push_damage = self.Flip and DIR_FLIP or direction
	local target = p2
	local target2 = p2 + DIR_VECTORS[direction]
	local target3 = p2 + DIR_VECTORS[direction] + DIR_VECTORS[(direction + 1)% 4]
	local target4 = p2 + DIR_VECTORS[direction] + DIR_VECTORS[(direction - 1)% 4]
	local damage = SpaceDamage(target, (self.Damage + self.MeleeDamage))
	local damage2 = SpaceDamage(target2, self.Damage)
	local damage3 = SpaceDamage(target3, self.Damage)
	local damage4 = SpaceDamage(target4, self.Damage)
	if Board:GetPawn(target) ~= nil then
		damage.iAcid = EFFECT_CREATE
	end
	if Board:GetPawn(target2) ~= nil then
		damage2.iAcid = EFFECT_CREATE
	end
	if Board:GetPawn(target3) ~= nil then
		damage3.iAcid = EFFECT_CREATE
	end
	if Board:GetPawn(target4) ~= nil then
		damage4.iAcid = EFFECT_CREATE
	end
	if self.Push == 1 then
		damage2.iPush = direction
		damage3.iPush = direction
		damage4.iPush = direction
	end
	damage.sAnimation = "ExploFirefly1"
	damage2.sAnimation = "ExploFirefly1"
	damage3.sAnimation = "ExploFirefly1"
	damage4.sAnimation = "ExploFirefly1"

	ret:AddDamage(damage)
	ret:AddDamage(damage2)
	ret:AddDamage(damage3)
	ret:AddDamage(damage4)
	return ret
end	

-- ANCHORAGE SKILLS

Serf_Repair = Skill:new{	
	Name = "First Aid",
	Description = "Recover the health of an adjacent unit by 1. Does +1 healing to Analogues, and can resurrect Squad Mechs or deployed Analogues.",
	Icon = "weapons/serf_firstaid.png",
	Class = "",
	Amount = -1,
	ArtillerySize = 1,
	Boost = false,
	TipImage = {
		Unit = Point(3,2),
		Enemy = Point(2,2),
		Target = Point(2,2),
		CustomPawn = "Deploy_SerfPuppet",
		CustomEnemy = "Deploy_ColonyAnalogue",
	},
}

Serf_Repair_2 = Serf_Repair:new{
	Description = "Recover the health of an adjacent unit by 2 and boost its next attack. Does +1 healing to Analogues, and can resurrect Squad Mechs or deployed Analogues.",
	Amount = -2,
	Boost = true,
}

function Serf_Repair:GetTargetArea(point)
	local ret = PointList()
	
	for dir = DIR_START, DIR_END do
		for i = 1,self.ArtillerySize do
			local curr = Point(point + DIR_VECTORS[dir] * i)
			if not Board:IsValid(curr) then
				break
			end
			
			if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
				ret:push_back(curr)
			end

		end
	end
	
	return ret
end

function isPawnAnalogue(point)
	local target = Board:GetPawn(point)

	if target ~= nil then
		target = target:GetType()
		if target == "Deploy_ColonyAnalogue" or target == "Deploy_ColonyAnalogue_2" or target == "Deploy_ColonyAnalogue_3" or target == "Deploy_ColonyAnalogue_4" then return true
		elseif target == "Deploy_ProvinceAnalogue" or target == "Deploy_ProvinceAnalogue_2" or target == "Deploy_ProvinceAnalogue_3" or target == "Deploy_ProvinceAnalogue_4" then return true
		elseif target == "SovereigntyAnalogue" or target == "FederationAnalogue" then return true else
			return false
		end
	else
		return false
	end
end

function Serf_Repair:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local damage = SpaceDamage(p2,self.Amount)
	damage.iFire = EFFECT_REMOVE
	damage.iAcid = EFFECT_REMOVE
	if Board:GetPawn(p2) ~= nil then
		if isPawnAnalogue(p2) and Board:GetPawn(p2):GetHealth() == 0 then
			ret:AddScript("Board:GetPawn("..p2:GetString().."):SetHealth(1)")
			damage.iDamage = damage.iDamage + 1
		end
	end
	if Board:GetPawn(p2) ~= nil and self.Boost == true then
		damage.sScript = "Board:GetPawn("..p2:GetString().."):SetBoosted(true)"
	end
	if isPawnAnalogue(p2) then
		damage.iDamage = damage.iDamage - 1
	end
	ret:AddDamage(damage)
	
	return ret
end

Serf_Pila = TankDefault:new{
	Name = "Pilum Toss",
	Description = "Throw a heavy pilum at a single tile, dealing damage and flipping the target.",
	Explo = "explopush1_",
	Icon = "weapons/serf_pilum.png",
	Class = "",
	Damage = 1,
	PushBack = 0,
	BackShot = 0,
	ProjectileArt = "effects/shot_serfpilum",
	Push = 0,
	Freeze = 0,
	Acid = 0,
	Flip = 1,
	Fire = 0,
	Shield = 0,
	Phase = false,
	PhaseShield = false,
	ZoneTargeting = ZONE_DIR,
}

Serf_Pila_2 = Serf_Pila:new{
	Damage = 2,
}

Deploy_SerfPuppet = Pawn:new{
	Name = "Serf Puppet",
	Health = 1,
	MoveSpeed = 4,
	Flying = true,
    Image = "SerfPuppet",
--    ImageOffset = 14, (Switched to preset colours in v0.2 to avoid a bug)
	SkillList = { "Serf_Repair" },
	--SoundLocation = "/support/civilian_tank/", -- not implemented
	SoundLocation = "/mech/brute/tank",
	DefaultTeam = TEAM_PLAYER,
	ImpactMaterial = IMPACT_METAL,
	Corpse = true,
	--Corporate = true
}

Deploy_SerfPuppet_2 = Deploy_SerfPuppet:new{
	Health = 1,
	MoveSpeed = 4,
	SkillList = { "Serf_Repair_2" },
}

Deploy_ColonyShove = Prime_Punchmech:new{  
	Class = "",
	Name = "Middleweight Shove",
	Description = "Damage and push an adjacent tile.",
	Icon = "weapons/middleweightshove.png",
	Rarity = 0,
	Explosion = "",
	LaunchSound = "/weapons/titan_fist",
	Range = 1, -- Tooltip?
	PathSize = 1,
	Damage = 1,
	PushBack = false,
	Flip = false,
	Dash = false,
	Shield = false,
	Projectile = false,
	Push = 1, --Mostly for tooltip, but you could turn it off for some unknown reason
	PowerCost = 0, --AE Change
	Upgrades = 0,
	TipImage = StandardTips.Melee
}

Deploy_ColonyShove_2 = Deploy_ColonyShove:new{
	Damage = 2,
}

Deploy_ColonyBuild = Skill:new{
	Class = "",
	Name = "Construct Building",
	Description = "Upgrade this unit to enable an advanced ability. Top-Left and Right will add an Emplacement with a lower-power replica of the Anchorage Beam, and Bottom-Left and Right will add a Foundry, increasing Serf population by 1 and allowing the arming of Serfs with crafted weapons.",
	Deployed = "Deploy_SerfPuppet",
	Icon = "weapons/colonyconstruct.png",
	Option1 = "Colony_Foundry",
	Option2 = "Colony_Beam",
	Rarity = 0,
	Explosion = "",
	TipImage = {
		Unit = Point(3,1),
		Target = Point(2,1),
		Second_Origin = Point(3,1),
		Second_Target = Point(4,1),
	},
}

Deploy_ColonyBuild_2 = Deploy_ColonyBuild:new{
	Option1 = "Colony_Foundry_2",
	Option2 = "Colony_Beam_2",
}

Deploy_ColonyBuild_3 = Deploy_ColonyBuild:new{
	Option1 = "Colony_Foundry_3",
	Option2 = "Colony_Beam_3",
	Deployed = "Deploy_SerfPuppet_2",
}

Deploy_ColonyBuild_4 = Deploy_ColonyBuild:new{
	Option1 = "Colony_Foundry_4",
	Option2 = "Colony_Beam_4",
	Deployed = "Deploy_SerfPuppet_2",
}

function Deploy_ColonyBuild:GetTargetArea(point)
	local ret = PointList()
	
	for i = DIR_START, DIR_END do
		local curr = DIR_VECTORS[i] + point
		if Board:IsValid(curr) and not Board:IsBlocked(curr, Pawn:GetPathProf()) then
			ret:push_back(curr)
		end
	end
	
	return ret
end

function Deploy_ColonyBuild:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)
	local owner = Board:GetPawn(p1)
	local opt1 = self.Option1
	local opt2 = self.Option2

	local damage = SpaceDamage(p1,0)
	damage.sScript = "Board:GetPawn("..p1:GetString().."):RemoveWeapon(2)"
	ret:AddDamage(damage)

	if direction == 3 or direction == 0 then
		local createunit = SpaceDamage(p2,0)
		LOG(self.Deployed)
		createunit.sPawn = self.Deployed
		ret:AddDamage(createunit)
		damage.sScript = [[Board:GetPawn(]]..p1:GetString()..[[):AddWeapon("]]..opt1..[[", true)]]
		damage.sImageMark = "combat/icons/icon_addfoundry.png"
	else
		damage.sScript = [[Board:GetPawn(]]..p1:GetString()..[[):AddWeapon("]]..opt2..[[", true)]]
		damage.sImageMark = "combat/icons/icon_addemplacement.png"
	end
	ret:AddDamage(damage)

	return ret
end

Colony_Foundry = Skill:new{
	Class = "",
	Name = "Bard Serf",
	Description = "Arm an adjacent Serf with additional durability and a bundle of throwable pila. Each Serf can only be upgraded in this manner once.",
	Icon = "weapons/colonybard.png",
	HealthBonus = 1,
	AddedWeapon = "Serf_Pila",
	Rarity = 0,
	Explosion = "",
	TipImage = {
		Unit = Point(3,4),
		Enemy = Point(2,4),
		Target = Point(2,4),
		CustomEnemy = "Deploy_SerfPuppet"
	},
}

Colony_Foundry_2 = Colony_Foundry:new{
	HealthBonus = 2,
}

Colony_Foundry_3 = Colony_Foundry:new{
	AddedWeapon = "Serf_Pila_2",
}

Colony_Foundry_4 = Colony_Foundry:new{
	HealthBonus = 2,
	AddedWeapon = "Serf_Pila_2",
}

function Colony_Foundry:GetTargetArea(point)
	local ret = PointList()
	
	for i = DIR_START, DIR_END do
		local curr = DIR_VECTORS[i] + point
		local query = Board:GetPawn(curr)
		if query ~= nil then
			if Board:IsValid(curr) and (query:GetType() == "Deploy_SerfPuppet" or query:GetType() == "Deploy_SerfPuppet_2") and query:GetMaxHealth() == 1 then
				ret:push_back(curr)
			end
		end
	end
	
	return ret
end

function Colony_Foundry:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)
	local owner = Board:GetPawn(p1)
	local healthboost = 1 + self.HealthBonus
	local addedweapon = self.AddedWeapon

	local damage = SpaceDamage(p2,0)
	damage.sScript = [[Board:GetPawn(]]..p2:GetString()..[[):SetMaxHealth(]]..healthboost..[[)]]
	ret:AddDamage(damage)
	damage.sScript = [[Board:GetPawn(]]..p2:GetString()..[[):AddWeapon("]]..addedweapon..[[", true)]]
	damage.iDamage = -1
	damage.sImageMark = "combat/icons/icon_addfoundry.png"
	ret:AddDamage(damage)

	return ret
end

Colony_Beam = Perpendicular_Beam:new{
	Class = "",
	Name = "Colony Beam",
	Description = "Strafes a small beam across an area, dealing damage and pushing the target away from the user relative to the beam's origin.",
	Icon = "weapons/colonybeam.png",
	Damage = 1,
	BeamRange = 2, -- The beam hits this number of tiles
	PowerCost = 0,
	FriendlyDamage = true,
	StrafeExplosion = "explopush1_",
	LaserAnimation = "ExploAir1",
	LaserArt = "effects/laseranch",
	LaunchSound = "/weapons/burst_beam",
	TipImage = {
		Unit = Point(3,4),
		Enemy = Point(2,4),
		Building = Point(2,3),
		Friendly = Point(2,2),
		Enemy2 = Point(2,1),
		Target = Point(2,4),
		Second_Click = Point(2,3),
	},
}

Colony_Beam_2 = Colony_Beam:new{
	BeamRange = 3, -- The beam hits this number of tiles
}

Colony_Beam_3 = Colony_Beam:new{
	Damage = 2,
}

Colony_Beam_4 = Colony_Beam:new{
	Damage = 2,
	BeamRange = 3, -- The beam hits this number of tiles
}

Deploy_ColonyAnalogue = Pawn:new{
	Name = "Colony Analogue",
	Health = 2,
	MoveSpeed = 2,
	Massive = true,
    Image = "ColonyAnalogue",
--    ImageOffset = 15, (Switched to preset colours in v0.2 to avoid a bug)
	SkillList = { "Deploy_ColonyShove" , "Deploy_ColonyBuild" },
	--SoundLocation = "/support/civilian_tank/", -- not implemented
	SoundLocation = "/mech/brute/tank",
	DefaultTeam = TEAM_PLAYER,
	ImpactMaterial = IMPACT_METAL,
	Corpse = true,
	--Corporate = true
}

Deploy_ColonyAnalogue_2 = Deploy_ColonyAnalogue:new{
	SkillList = { "Deploy_ColonyShove" , "Deploy_ColonyBuild_2" },
}

Deploy_ColonyAnalogue_3 = Deploy_ColonyAnalogue:new{
	Health = 3,
	SkillList = { "Deploy_ColonyShove_2" , "Deploy_ColonyBuild_3" },
}

Deploy_ColonyAnalogue_4 = Deploy_ColonyAnalogue:new{
	Health = 3,
	SkillList = { "Deploy_ColonyShove_2" , "Deploy_ColonyBuild_4" },
}

DeploySkill_Anchorage_Mixed = Deployable:new{
	Name = "Spawn Serf/Colony",
	Description = "Spawn a Serf at range or a Colony in melee. Serfs are nimble support units, Colonies are heavier assistants to their parent Anchorages. Limited uses.",
	Icon = "weapons/anchorage_mixedspawn.png",
	Class = "Prime",
	Rarity = 1,
	Deployed = "",
	DeployedClose = "Deploy_ColonyAnalogue",
	DeployedRange = "Deploy_SerfPuppet",
	RangedDupe = false,
	Projectile = "effects/shotup_serf.png",
	Limited = 2,
	Upgrades = 2,
	UpgradeCost = {2,2},
	LaunchSound = "/weapons/deploy_tank",
	ImpactSound = "/impact/generic/mech",
	TipImage = {
		Unit = Point(2,3),
		Target = Point(2,0),
		Enemy = Point(4,1),
		Second_Origin = Point(2,3),
		Second_Target = Point(2,2),
	},
}

DeploySkill_Anchorage_Mixed_A = DeploySkill_Anchorage_Mixed:new{
	Description = "Spawn a pair of Serfs at range or a Colony in melee. Serfs are nimble support units, Colonies are heavier assistants to their parent Anchorages. Limited uses.",
	UpgradeDescription = "Serfs are now spawned in pairs. Colonies get enhanced abilities.",
	DeployedClose = "Deploy_ColonyAnalogue_2",
	RangedDupe = true,
}

DeploySkill_Anchorage_Mixed_B = DeploySkill_Anchorage_Mixed:new{
	UpgradeDescription = "Serfs and Colonies are both enhanced.",
	DeployedClose = "Deploy_ColonyAnalogue_3",
	DeployedRange = "Deploy_SerfPuppet_2",
}

DeploySkill_Anchorage_Mixed_AB = DeploySkill_Anchorage_Mixed:new{
	Description = "Spawn a pair of Serfs at range or a Colony in melee. Serfs are nimble support units, Colonies are heavier assistants to their parent Anchorages. Limited uses.",
	DeployedClose = "Deploy_ColonyAnalogue_4",
	DeployedRange = "Deploy_SerfPuppet_2",
	RangedDupe = true,
}

function DeploySkill_Anchorage_Mixed:GetTargetArea(point)
	local ret = PointList()

	for dir = DIR_START, DIR_END do
		for i = 1, 1 do
			local curr = Point(point + DIR_VECTORS[dir] * i)
			if not Board:IsValid(curr) then
				break
			end
			
			if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
				ret:push_back(curr)
			end

		end
	end
	
	if self.RangedDupe then
		for dir = DIR_START, DIR_END do
			for i = 2, self.ArtillerySize do
				local curr = Point(point + DIR_VECTORS[dir] * i)
				local curr2 = Point(point + DIR_VECTORS[dir] * (i - 1))
				if not Board:IsValid(curr) then
					break
				end
				
				if (not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND)) and (not self.OnlyEmpty or not Board:IsBlocked(curr2,PATH_GROUND)) then
					ret:push_back(curr)
				end

			end
		end
	else
		for dir = DIR_START, DIR_END do
			for i = 2, self.ArtillerySize do
				local curr = Point(point + DIR_VECTORS[dir] * i)
				if not Board:IsValid(curr) then
					break
				end
				
				if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
					ret:push_back(curr)
				end
			end
		end
	end
	
	return ret
end

function DeploySkill_Anchorage_Mixed:GetSkillEffect(p1, p2)	
	local ret = SkillEffect()	
	local damage = SpaceDamage(p2,0)
	local direction = GetDirection(p2 - p1)
	local ismelee = false
	for dir = 0, 3 do
		if p2 - DIR_VECTORS[dir] == p1 then ismelee = true end
	end
	if ismelee == true then
		damage.sPawn = self.DeployedClose
		ret:AddDamage(damage)
	else
		damage.sPawn = self.DeployedRange
		ret:AddArtillery(damage,self.Projectile)
		if self.RangedDupe then
			damage.loc = p2 - DIR_VECTORS[direction]
			ret:AddArtillery(damage,self.Projectile)
		end
	end
	return ret
end	

Anchorage_Beam = Perpendicular_Beam:new{
	Class = "Prime",
	Name = "Anchorage Beam",
	Description = "Strafes a beam across an area, dealing damage and pushing the target away from the user relative to the beam's origin.",
	Icon = "weapons/anchoragebeam.png",
	Damage = 1,
	BeamRange = 3, -- The beam hits this number of tiles
	PowerCost = 0,
	Upgrades = 2,
	UpgradeCost = {1,3},
	FriendlyDamage = true,
	StrafeExplosion = "explopush1_",
	LaserAnimation = "ExploAir1",
	LaserArt = "effects/laseranch",
	LaunchSound = "/weapons/burst_beam",
	TipImage = {
		Unit = Point(3,4),
		Enemy = Point(2,4),
		Building = Point(2,3),
		Friendly = Point(2,2),
		Enemy2 = Point(2,1),
		Target = Point(2,4),
		Second_Click = Point(2,3),
	},
}

Anchorage_Beam_A = Anchorage_Beam:new{
	UpgradeDescription = "Strafing the beam over allies or buildings deals no damage and extends the beam's reach.",
	FriendlyDamage = false,
}

Anchorage_Beam_B = Anchorage_Beam:new{
	UpgradeDescription = "Increases beam damage and range by 1.",
	Damage = 2,
	BeamRange = 4,
}

Anchorage_Beam_AB = Anchorage_Beam:new{
	FriendlyDamage = false,
	Damage = 2,
	BeamRange = 4,
}

-- SOVEREIGNTY SKILLS

Sovereignty_Machinegun = Skill:new{	
	Name = "Suppressive Fire",
	Description = "Suppressive fire that damages a large area with no effect on buildings. Boost increases damage reach.",
	Icon = "weapons/sovereignty_machinegun.png",
	Class = "Brute",
	SelfDamage = 2,
	Damage = 1,
	Length = 2, --Determines the length of the attack.
	NarrowLength = 1, --Determines how many tiles the "width" attribute does NOT effect.
	Width = 0, --Determines how wide the wide area is.
	ArtillerySize = 1,
	Upgrades = 2,
	UpgradeCost = {2,2},
	DamageBuildings = false,
	DamageAllies = true,
	FlushFire = false,
	OnlyEmpty = false,
	Anim = "BulletBarrage",
	TipImage = {
		Unit = Point(2,1),
		Target = Point(2,2),
		Enemy = Point(2,2),
		Building = Point(2,3),
		Friendly = Point(2,4),
		Enemy2 = Point(3,3),
	},
}

Sovereignty_Machinegun_A = Sovereignty_Machinegun:new{	
	UpgradeDescription = "Adds width to the damage area, flushing targets into the center file. Prevents ally damage.",
	FlushFire = true,
	DamageAllies = false,
	Width = 1,
}

Sovereignty_Machinegun_B = Sovereignty_Machinegun:new{	
	UpgradeDescription = "Enhances damage to both self and targets.",
	SelfDamage = 3,
	Damage = 2,
}

Sovereignty_Machinegun_AB = Sovereignty_Machinegun:new{	
	SelfDamage = 3,
	Damage = 2,
	Width = 1,
	FlushFire = true,
	DamageAllies = false,
}

function Sovereignty_Machinegun:GetTargetArea(point)
	local ret = PointList()
	
	for dir = DIR_START, DIR_END do
		for i = 1,self.ArtillerySize do
			local curr = Point(point + DIR_VECTORS[dir] * i)
			if not Board:IsValid(curr) then
				break
			end
			
			if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
				ret:push_back(curr)
			end

		end
	end
	
	return ret
end

function Sovereignty_Machinegun:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local damage = SpaceDamage(p2,self.Damage)
	local dir = GetDirection(p2 - p1)
	local reach = self.Length
	damage.sAnimation = self.Anim

	if self.SelfDamage > 0 then
		local damageself = SpaceDamage(p1,self.SelfDamage)
		if Board:GetPawn(p1):IsBoosted() then
			damageself.iDamage = self.SelfDamage - 1
		end
		ret:AddDamage(damageself)
	end

	if Board:GetPawn(p1):IsBoosted() then
		reach = reach + 1
	end

	for i = 0,reach do
		damage = SpaceDamage(p2,self.Damage)
		damage.sAnimation = self.Anim
		damage.loc = p2 + (DIR_VECTORS[dir]*i)
		if (not self.DamageBuildings and Board:IsBuilding(damage.loc)) or (not self.DamageAllies and Board:IsPawnTeam(damage.loc, TEAM_PLAYER)) then
			damage.iDamage = DAMAGE_ZERO
		else
			damage.iDamage = self.Damage
		end
		ret:AddDamage(damage)
		if i >= self.NarrowLength and self.Width > 0 then
			for j = 1,self.Width do
				damage.loc = p2 + (DIR_VECTORS[dir]*i) + (DIR_VECTORS[(dir+1)%4]*j)
				if (not self.DamageBuildings and Board:IsBuilding(damage.loc)) or (not self.DamageAllies and Board:IsPawnTeam(damage.loc, TEAM_PLAYER)) then
					damage.iDamage = DAMAGE_ZERO
				else
					damage.iDamage = self.Damage
				end
				if self.FlushFire then
					damage.iPush = (dir+3)%4
				end
				ret:AddDamage(damage)
				damage.loc = p2 + (DIR_VECTORS[dir]*i) + (DIR_VECTORS[(dir+3)%4]*j)
				if (not self.DamageBuildings and Board:IsBuilding(damage.loc)) or (not self.DamageAllies and Board:IsPawnTeam(damage.loc, TEAM_PLAYER)) then
					damage.iDamage = DAMAGE_ZERO
				else
					damage.iDamage = self.Damage
				end
				if self.FlushFire then
					damage.iPush = (dir+1)%4
				end
				ret:AddDamage(damage)
			end
		end
	end

	return ret
end

Sovereignty_MagicMissile = Skill:new{
	Name = "Magic Missile",
	Description = "A heavy-hitting free-aim missile that pushes the target in a chosen direction. Boosting gives even more damage, but also causes self damage.",
	Class = "Brute",
	Icon = "weapons/sovereignty_magicmissile.png",
	UpShot = "effects/shotup_magicmissile.png",
	ArtilleryStart = 1, --This is the inner bounds of the square. 1 = Adjacent tiles
	ArtillerySize = 5, --Determines the outer bounds of the square. 1 = Adjacent tiles
	BuildingDamage = true,
	SelfDamage = 1,
	DamageCenter = 3,
	DamageBoost = 2,
	TwoClick = true,
	RollOff = false,
	Limited = 2,
	Upgrades = 2,
	UpgradeCost = {2,2},
	PowerCost = 0, --AE Change
	Damage = 3,---USED FOR TOOLTIPS
	BounceAmount = 1,
	Explosion = "",
	ExplosionCenter = "ExploArt1",
	ExplosionOuter = "ExploArt1",
	OuterAnimation = "explopush1_",
	LaunchSound = "/weapons/artillery_volley",
	ImpactSound = "/impact/generic/explosion",
	TipImage = {
		Unit = Point(2,1),
		Target = Point(2,3),
		Second_Click = Point(2,2),
		Enemy = Point(2,3),
		Enemy2 = Point(2,2),
	},
}

Sovereignty_MagicMissile_A = Sovereignty_MagicMissile:new{
	UpgradeDescription = [[Half (rounded up) of the missile's damage "rolls off" onto the tile the target is pushed into.]],
	RollOff = true,
}

Sovereignty_MagicMissile_B = Sovereignty_MagicMissile:new{
	UpgradeDescription = [[Adds one more use of magic missile and increases base damage by 1.]],
	Limited = 3,
	DamageCenter = 4,
}

Sovereignty_MagicMissile_AB = Sovereignty_MagicMissile:new{
	Limited = 3,
	DamageCenter = 4,
	RollOff = true,
}

function Sovereignty_MagicMissile:GetTargetArea(point)
	local ret = PointList()
	local minrange = self.ArtilleryStart
	
	for dir = DIR_START, DIR_END do
		for i = minrange, self.ArtillerySize do
			local curr = Point(point + DIR_VECTORS[dir] * i)
			if not Board:IsValid(curr) then
				break
			end
			
			if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
				ret:push_back(curr)
			end

			for j = 1, self.ArtillerySize do
				local curralt = Point(curr + DIR_VECTORS[(dir+1)%4] * j)
				if not Board:IsValid(curralt) then
					break
				end
				
				if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
					ret:push_back(curralt)
				end
			end

			if minrange > 1 then
				for k = 1, (minrange - 1) do
					local curralt = Point(curr + DIR_VECTORS[(dir-1)%4] * k)
					if not Board:IsValid(curralt) then
						break
					end
					
					if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
						ret:push_back(curralt)
					end
				end
			end

		end
	end
	
	return ret
end

function Sovereignty_MagicMissile:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local damage = SpaceDamage(p2,self.DamageCenter)
	damage.sAnimation = self.ExplosionCenter
	if Board:GetPawn(p1):IsBoosted() then
		damage.iDamage = self.DamageCenter + self.DamageBoost
	end

	if self.SelfDamage > 0 then
		ret:AddDamage(SpaceDamage(p1,self.SelfDamage))
	end


	if not self.BuildingDamage and Board:IsBuilding(p2) then		-- Target Buildings - 
		damage.iDamage = DAMAGE_ZERO
	end

	ret:AddArtillery(damage, self.UpShot)
	
	return ret
end

function Sovereignty_MagicMissile:GetSecondTargetArea(p1,p2)
	-- Pick a push direction
	local ret = PointList()
	local direction = GetDirection(p2-p1)

	for dir = 0,3 do
		local curr = Point(p2 + DIR_VECTORS[dir])
		ret:push_back(curr)
	end

	return ret
end

function Sovereignty_MagicMissile:GetFinalEffect(p1, p2, p3)
	local ret = SkillEffect()
	local damage = SpaceDamage(p2,self.DamageCenter)
	local direction = GetDirection(p3-p2)
	damage.sAnimation = self.ExplosionCenter..direction
	damage.iPush = direction
	if Board:GetPawn(p1):IsBoosted() then
		damage.iDamage = self.DamageCenter + self.DamageBoost
	end

	if self.SelfDamage > 0 then
		ret:AddDamage(SpaceDamage(p1,self.SelfDamage))
	end


	if not self.BuildingDamage and Board:IsBuilding(p2) then		-- Target Buildings - 
		damage.iDamage = DAMAGE_ZERO
	end

	ret:AddArtillery(damage, self.UpShot)

	if self.RollOff then
		local rolldamage = (self.DamageCenter / 2) + 1
		local rolloff = SpaceDamage(p2 + DIR_VECTORS[direction],rolldamage)
		rolloff.sAnimation = self.ExplosionOuter
		ret:AddDamage(rolloff)
	end
	
	return ret
end

-- FEDERATION SKILLS

Federation_BigShove = Skill:new{  
	Class = "Science",
	Name = "Heavyweight Shove",
	Description = "Pushes a tile, damaging enemies, repairing allies, or leaving buildings unharmed. Boost makes the skill hit all adjacent tiles at reduced effect.",
	Icon = "weapons/heavyweightshove.png",
	Rarity = 0,
	Explosion = "",
	LaunchSound = "/weapons/titan_fist",
	Range = 1, -- Tooltip?
	PathSize = 1,
	Damage = 1,
	DamagePrimary = 1,
	Push = 1, --Mostly for tooltip, but you could turn it off for some unknown reason
	PowerCost = 0, --AE Change
	Upgrades = 2,
	--UpgradeList = { "Dash",  "+2 Damage"  },
	UpgradeCost = { 1,3 },
	TipImage = {
		Unit = Point(2,3),
		Enemy = Point(2,2),
		Target = Point(2,2),
		Friendly = Point(3,3),
		Second_Origin = Point(2,3),
		Second_Target = Point(3,3),
	},
}

Federation_BigShove_A = Federation_BigShove:new{
	UpgradeDescription = "Increases damage to the target tile by 1.",
	DamagePrimary = 2,
}
				
Federation_BigShove_B = Federation_BigShove:new{
	UpgradeDescription = "Increases damage to all target tiles by 1.",
	Damage = 2,
}
				
Federation_BigShove_AB = Federation_BigShove:new{
	Damage = 2,
	DamagePrimary = 2,
}
				
function Federation_BigShove:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)

	if Board:GetPawn(p1):IsBoosted() then
		for i = 0,3 do
			local target = p1 + DIR_VECTORS[i]
			local damage = SpaceDamage(target,self.Damage)
			damage.sAnimation = "explopush1_"..i
			if i == direction then
				damage.iDamage = self.Damage + self.DamagePrimary
			end
			damage.iPush = i

			if Board:IsBuilding(target) then
				damage.iDamage = DAMAGE_ZERO
				damage.sAnimation = "airpush_"..i
			end

			if Board:IsPawnTeam(target, TEAM_PLAYER) then
				damage.sAnimation = "airpush_"..i
				damage.iDamage = -damage.iDamage
			end

			ret:AddDamage(damage)
		end
	else
		local target = p1 + DIR_VECTORS[direction]
		local damage = SpaceDamage(target,self.Damage + self.DamagePrimary)
		damage.sAnimation = "explopush1_"..direction
		damage.iPush = direction

		if Board:IsBuilding(target) then
			damage.sAnimation = "airpush_"..direction
			damage.iDamage = DAMAGE_ZERO
		end

		if Board:IsPawnTeam(target, TEAM_PLAYER) then
			damage.sAnimation = "airpush_"..direction
			damage.iDamage = -damage.iDamage
		end

		ret:AddDamage(damage)
	end
	return ret
end	

Province_Pullstrike = Skill:new{
	Name = "Down Shot",
	Description = "Leap a target, damaging and pushing it into the space this unit started.",
	Class = "",
	Icon = "weapons/downshot.png",
	Rarity = 0,
	AttackAnimation = "explopush1_",
	ExplosionStill = "ExploArt1",
	Sound = "/general/combat/stun_explode",
	MinMove = 2,
	Range = 2,
	Damage = 1,
	AnimDelay = 0.2,
	Smoke = 0,
	Acid = 0,
	PowerCost = 0, --AE Change
	DoubleAttack = 0, --does it attack again after stopping moving
	Upgrades = 0,
	LaunchSound = "/weapons/bomb_strafe",
	BombSound = "/impact/generic/explosion",
	TipImage = {
		Unit = Point(2,3),
		Enemy = Point(2,2),
		Target = Point(2,1),
	}
}

Province_Pullstrike_2 = Province_Pullstrike:new{
	DoubleAttack = 1, --does it attack again after stopping moving
}

function Province_Pullstrike:GetTargetArea(point)
	local ret = PointList()
	for i = DIR_START, DIR_END do
		for k = self.MinMove, self.Range do
			if not Board:IsBlocked(DIR_VECTORS[i]*k + point, Pawn:GetPathProf()) then
				ret:push_back(DIR_VECTORS[i]*k + point)
			end
		end
	end
	
	return ret
end

function Province_Pullstrike:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local dir = GetDirection(p2 - p1)
	local pushdir = GetDirection(p1-p2)
	
	local move = PointList()
	move:push_back(p1)
	move:push_back(p2)
	
	local distance = p1:Manhattan(p2)
	
	ret:AddBounce(p1,2)
	if distance == 1 then
		ret:AddLeap(move, 0.5)--small delay between move and the damage, attempting to make the damage appear when unit is overhead
	else
		ret:AddLeap(move, 0.25)
	end
		
	for k = 1, (self.Range-1) do
		
		if p1 + DIR_VECTORS[dir]*k == p2 then
			break
		end
		
		local damage = SpaceDamage(p1 + DIR_VECTORS[dir]*k, self.Damage)
		
		damage.iSmoke = self.Smoke
		damage.iAcid = self.Acid
		damage.iPush = pushdir
		
		damage.sAnimation = self.AttackAnimation..pushdir
		damage.sSound = self.BombSound
		
		if k ~= 1 then
			ret:AddDelay(self.AnimDelay) --was 0.2
		end
		
		ret:AddDamage(damage)
		
		ret:AddBounce(p1 + DIR_VECTORS[dir]*k,3)
		
	--	ret:AddSound(self.BombLaunchSound)
	end
	
	if self.DoubleAttack == 1 then
		damage = SpaceDamage(p1, self.Damage)
--		damage.sAnimation = self.ExplosionStill
		ret:AddDelay(0.5) --We add a delay here in the hopes the target is pushed to the origin tile by the time swing number two comes out.
		ret:AddDamage(damage)
	end
	
	
	return ret
end

Province_BusterMissile = Skill:new{
	Range = RANGE_PROJECTILE,
	PathSize = INT_MAX,
	Name = "Buster Missile",
	Description = "A hard-hitting missile that deals high damage to the target tile and the tile behind it.",
	Explo = "explopush1_",
	Icon = "weapons/bustermissile.png",
	Class = "",
	Damage = 2,
	Limited = 1,
	PushBack = 0,
	BackShot = 0,
	ProjectileArt = "effects/shot_bustermissile",
	Push = 0,
	Freeze = 0,
	Acid = 0,
	Flip = 0,
	Fire = 0,
	Shield = 0,
	Phase = false,
	PhaseShield = false,
	ZoneTargeting = ZONE_DIR,
	TipImage = {
		Unit = Point(2,0),
		Enemy = Point(2,2),
		Enemy_2 = Point(2,3),
		Target = Point(2,1),
	}
}

Province_BusterMissile_2 = Province_BusterMissile:new{
	Damage = 4,
}

function Province_BusterMissile:GetTargetArea(p1)

	if not self.Phase then
		return Board:GetSimpleReachable(p1, self.PathSize, self.CornersAllowed)
	else
		local ret = PointList()
	
		for dir = DIR_START, DIR_END do
			for i = 1, 8 do
				local curr = Point(p1 + DIR_VECTORS[dir] * i)
				if not Board:IsValid(curr) then
					break
				end
				
				ret:push_back(curr)
				
				if Board:IsBlocked(curr,PATH_PHASING) then
					break
				end
			end
		end
	
	return ret
	
	end
end

function Province_BusterMissile:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)

	if self.PushBack == 1 then
		local selfDam = SpaceDamage(p1, self.SelfDamage, GetDirection(p1 - p2))
		ret:AddDamage(selfDam)
	end

	local pathing = self.Phase and PATH_PHASING or PATH_PROJECTILE
	local target = GetProjectileEnd(p1,p2,pathing)  
	
	local damage = SpaceDamage(target, self.Damage)
	if self.Flip == 1 then
		damage = SpaceDamage(target,self.Damage,DIR_FLIP)
	end
	if self.Push == 1 then
		damage.iPush = direction
	end
	damage.iAcid = self.Acid
	damage.iFrozen = self.Freeze
	damage.iFire = self.Fire
	damage.iShield = self.Shield
	damage.sAnimation = self.Explo..direction
	
	if self.Phase and Board:IsBuilding(target) then
		damage.sAnimation = ""
		damage.iDamage = 0
	end
	
	ret:AddProjectile(damage, self.ProjectileArt)--"effects/shot_mechtank")
	damage.loc = target + DIR_VECTORS[direction]
	ret:AddDamage(damage)
	
	return ret
end

Deploy_ProvinceAnalogue = Pawn:new{
	Name = "Province Analogue",
	Health = 2,
	MoveSpeed = 3,
	Flying = true,
    Image = "ProvinceAnalogue",
--    ImageOffset = 15, (Switched to preset colours in v0.2 to avoid a bug)
	SkillList = { "Province_Pullstrike" },
	--SoundLocation = "/support/civilian_tank/", -- not implemented
	SoundLocation = "/mech/brute/tank",
	DefaultTeam = TEAM_PLAYER,
	ImpactMaterial = IMPACT_METAL,
	Corpse = true,
	--Corporate = true
}

Deploy_ProvinceAnalogue_2 = Deploy_ProvinceAnalogue:new{
	Name = "Province Analogue",
	MoveSpeed = 4,
	Armor = true,
	SkillList = { "Province_Pullstrike" },
}

Deploy_ProvinceAnalogue_3 = Deploy_ProvinceAnalogue:new{
	Name = "Province Analogue",
	SkillList = { "Province_Pullstrike_2" },
}

Deploy_ProvinceAnalogue_4 = Deploy_ProvinceAnalogue:new{
	Name = "Province Analogue",
	MoveSpeed = 4,
	Armor = true,
	SkillList = { "Province_Pullstrike_2" },
}

DeploySkill_ProvinceAnalogue = LineArtillery:new{
	Name = "Deploy Province",
	Description = "Deploy a Province Analogue to help out in combat. Boost adds a single use, hard-hitting missile attack to the deployed Province.",
	Icon = "weapons/provincespawn.png",
	Explosion = "",
	SelfDamage = 3,
	Deployed = "Deploy_ProvinceAnalogue",
	BoostSkill = "Province_BusterMissile",
	Projectile = "effects/shotup_province.png",
	Upgrades = 2,
	UpgradeCost = {2,2},
	Limited = 2,
	OnlyEmpty = true,
	Class = "Science",
	TipImage = {
		Unit = Point(1,3),
		Target = Point(1,1),
		Enemy = Point(2,1),
		Second_Origin = Point(1,1),
		Second_Target = Point(3,1),
	},
}

DeploySkill_ProvinceAnalogue_A = DeploySkill_ProvinceAnalogue:new{
	UpgradeDescription = "Adds Armor and movement range to the Provinces.",
	Deployed = "Deploy_ProvinceAnalogue_2",
	BoostSkill = "Province_BusterMissile",
}

DeploySkill_ProvinceAnalogue_B = DeploySkill_ProvinceAnalogue:new{
	UpgradeDescription = "Increases the effectiveness of the Provinces' weapons.",
	Deployed = "Deploy_ProvinceAnalogue_3",
	BoostSkill = "Province_BusterMissile_2",
}

DeploySkill_ProvinceAnalogue_AB = DeploySkill_ProvinceAnalogue:new{
	Deployed = "Deploy_ProvinceAnalogue_4",
	BoostSkill = "Province_BusterMissile_2",
}

function DeploySkill_ProvinceAnalogue:GetSkillEffect(p1, p2)	
	local ret = SkillEffect()	
	local damage = SpaceDamage(p2,0)
	local damage2 = SpaceDamage(p2,0)
	local damageself = SpaceDamage(p1,self.SelfDamage)
	if Board:GetPawn(p1):IsBoosted() then
		damageself.iDamage = self.SelfDamage - 1
	end
	ret:AddDamage(damageself)
	damage.sPawn = self.Deployed
	ret:AddArtillery(damage,self.Projectile)
	if Board:GetPawn(p1):IsBoosted() then
		damage2.sScript = [[Board:GetPawn(]]..p2:GetString()..[[):AddWeapon("]]..self.BoostSkill..[[", true)]]
	end
	ret:AddDamage(damage2)
	return ret
end