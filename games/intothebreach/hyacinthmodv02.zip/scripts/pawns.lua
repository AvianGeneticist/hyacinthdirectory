local mod = modApi:getCurrentMod()
local path = mod_loader.mods[modApi.currentMod].resourcePath
local mechPath = path .."img/units/player/"

local files = {
    "blankpuppet.png",
    "blankpuppet_a.png",
    "blankpuppet_w.png",
    "blankpuppet_w_broken.png",
    "blankpuppet_broken.png",
    "blankpuppet_ns.png",
    "blankpuppet_h.png",

    "manipulatorpuppet.png",
    "manipulatorpuppet_a.png",
    "manipulatorpuppet_w.png",
    "manipulatorpuppet_w_broken.png",
    "manipulatorpuppet_broken.png",
    "manipulatorpuppet_ns.png",
    "manipulatorpuppet_h.png",

    "tricksterpuppet.png",
    "tricksterpuppet_a.png",
    "tricksterpuppet_w.png",
    "tricksterpuppet_w_broken.png",
    "tricksterpuppet_broken.png",
    "tricksterpuppet_ns.png",
    "tricksterpuppet_h.png",

    "reconcilantpuppet.png",
    "reconcilantpuppet_a.png",
    "reconcilantpuppet_w.png",
    "reconcilantpuppet_w_broken.png",
    "reconcilantpuppet_broken.png",
    "reconcilantpuppet_ns.png",
    "reconcilantpuppet_h.png",

    "imppuppet.png",
    "imppuppet_a.png",
    "imppuppet_w_broken.png",
    "imppuppet_broken.png",
    "imppuppet_ns.png",
    "imppuppet_h.png",

    "howitzerpuppet.png",
    "howitzerpuppet_a.png",
    "howitzerpuppet_w.png",
    "howitzerpuppet_w_broken.png",
    "howitzerpuppet_broken.png",
    "howitzerpuppet_ns.png",
    "howitzerpuppet_h.png",

    "heraldpuppet.png",
    "heraldpuppet_a.png",
    "heraldpuppet_w.png",
    "heraldpuppet_w_broken.png",
    "heraldpuppet_broken.png",
    "heraldpuppet_ns.png",
    "heraldpuppet_h.png",

    "anchoragepuppet.png",
    "anchoragepuppet_a.png",
    "anchoragepuppet_w.png",
    "anchoragepuppet_w_broken.png",
    "anchoragepuppet_broken.png",
    "anchoragepuppet_ns.png",
    "anchoragepuppet_h.png",

    "serfpuppet.png",
    "serfpuppet_a.png",
    "serfpuppet_w_broken.png",
    "serfpuppet_broken.png",
    "serfpuppet_ns.png",
    "serfpuppet_h.png",

    "colonyanalogue.png",
    "colonyanalogue_a.png",
    "colonyanalogue_w.png",
    "colonyanalogue_w_broken.png",
    "colonyanalogue_broken.png",
    "colonyanalogue_ns.png",
    "colonyanalogue_h.png",

    "sovereigntyanalogue.png",
    "sovereigntyanalogue_a.png",
    "sovereigntyanalogue_w.png",
    "sovereigntyanalogue_w_broken.png",
    "sovereigntyanalogue_broken.png",
    "sovereigntyanalogue_ns.png",
    "sovereigntyanalogue_h.png",

    "federationanalogue.png",
    "federationanalogue_a.png",
    "federationanalogue_w.png",
    "federationanalogue_w_broken.png",
    "federationanalogue_broken.png",
    "federationanalogue_ns.png",
    "federationanalogue_h.png",

    "provinceanalogue.png",
    "provinceanalogue_a.png",
    "provinceanalogue_w_broken.png",
    "provinceanalogue_broken.png",
    "provinceanalogue_ns.png",
    "provinceanalogue_h.png",
}


for _, file in ipairs(files) do
    modApi:appendAsset("img/units/player/".. file, mechPath .. file)
end

    modApi:addPalette({
    ID = "PuppetPalette",
    Name = "Hyacinth's Puppets",
    Image = "units/player/blankpuppet_ns.png",
    PlateHighlight = {239,198,237},
    PlateLight     = {214,145,210},
    PlateMid       = {184,103,180},
    PlateDark      = {123,48,119},
    PlateOutline   = {58,19,56},
    PlateShadow    = {116,153,182},
    BodyColor      = {200,223,241},
    BodyHighlight  = {224,240,253},
    }
)

    modApi:addPalette({
    ID = "AnaloguePalette",
    Name = "Hyacinth's Analogues",
    Image = "units/player/sovereigntyanalogue_ns.png",
    PlateHighlight = {186,86,255},
    PlateLight     = {89,48,34},
    PlateMid       = {73,36,25},
    PlateDark      = {52,25,17},
    PlateOutline   = {24,10,7},
    PlateShadow    = {184,103,180},
    BodyColor      = {214,145,210},
    BodyHighlight  = {244,220,242},
    }
)

local a=ANIMS
a.BlankPuppet =a.MechUnit:new{Image="units/player/blankpuppet.png", PosX = -15, PosY = -9}
a.BlankPuppeta = a.MechUnit:new{Image="units/player/blankpuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.BlankPuppetw = a.MechUnit:new{Image="units/player/blankpuppet_w.png", -15, PosY = -9}
a.BlankPuppet_broken = a.MechUnit:new{Image="units/player/blankpuppet_broken.png", PosX = -15, PosY = -9 }
a.BlankPuppetw_broken = a.MechUnit:new{Image="units/player/blankpuppet_w_broken.png", PosX = -15, PosY = -9 }
a.BlankPuppet_ns = a.MechIcon:new{Image="units/player/blankpuppet_ns.png"}




BlankPuppet = Pawn:new{
    Name = "Blank Puppet",
    Class = "Prime",
    Health = 3,
    MoveSpeed = 3,
    Massive = true,
    Corpse = true,
    Image = "BlankPuppet",
    ImageOffset = 14,
    SkillList = {"FreeAimArtillery","FreeAimArtilleryTwoClick"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("BlankPuppet")

local a=ANIMS
a.ManipulatorPuppet =a.MechUnit:new{Image="units/player/manipulatorpuppet.png", PosX = -15, PosY = -9}
a.ManipulatorPuppeta = a.MechUnit:new{Image="units/player/manipulatorpuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.ManipulatorPuppetw = a.MechUnit:new{Image="units/player/manipulatorpuppet_w.png", -15, PosY = -9}
a.ManipulatorPuppet_broken = a.MechUnit:new{Image="units/player/manipulatorpuppet_broken.png", PosX = -15, PosY = -9 }
a.ManipulatorPuppetw_broken = a.MechUnit:new{Image="units/player/manipulatorpuppet_w_broken.png", PosX = -15, PosY = -9 }
a.ManipulatorPuppet_ns = a.MechIcon:new{Image="units/player/manipulatorpuppet_ns.png"}


ManipulatorPuppet = Pawn:new{
    Name = "Manipulator Puppet",
    Class = "Prime",
    Health = 3,
    MoveSpeed = 3,
    Massive = true,
    Corpse = true,
    Image = "ManipulatorPuppet",
    ImageOffset = 14,
    SkillList = {"Prime_Manipulator"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("ManipulatorPuppet")




local a=ANIMS
a.TricksterPuppet =a.MechUnit:new{Image="units/player/tricksterpuppet.png", PosX = -15, PosY = -9}
a.TricksterPuppeta = a.MechUnit:new{Image="units/player/tricksterpuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.TricksterPuppetw = a.MechUnit:new{Image="units/player/tricksterpuppet_w.png", -15, PosY = -9}
a.TricksterPuppet_broken = a.MechUnit:new{Image="units/player/tricksterpuppet_broken.png", PosX = -15, PosY = -9 }
a.TricksterPuppetw_broken = a.MechUnit:new{Image="units/player/tricksterpuppet_w_broken.png", PosX = -15, PosY = -9 }
a.TricksterPuppet_ns = a.MechIcon:new{Image="units/player/tricksterpuppet_ns.png"}


TricksterPuppet = Pawn:new{
    Name = "Trickster Puppet",
    Class = "Ranged",
    Health = 2,
    MoveSpeed = 3,
    Massive = true,
    Corpse = true,
    Image = "TricksterPuppet",
    ImageOffset = 14,
    SkillList = {"Ranged_TricksterPuppetBolt", "Ranged_TricksterFrostBeam"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("TricksterPuppet") 



local a=ANIMS
a.ReconcilantPuppet =a.MechUnit:new{Image="units/player/reconcilantpuppet.png", PosX = -15, PosY = -9}
a.ReconcilantPuppeta = a.MechUnit:new{Image="units/player/reconcilantpuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.ReconcilantPuppetw = a.MechUnit:new{Image="units/player/reconcilantpuppet_w.png", -15, PosY = -9}
a.ReconcilantPuppet_broken = a.MechUnit:new{Image="units/player/reconcilantpuppet_broken.png", PosX = -15, PosY = -9 }
a.ReconcilantPuppetw_broken = a.MechUnit:new{Image="units/player/reconcilantpuppet_w_broken.png", PosX = -15, PosY = -9 }
a.ReconcilantPuppet_ns = a.MechIcon:new{Image="units/player/reconcilantpuppet_ns.png"}


ReconcilantPuppet = Pawn:new{
    Name = "Reconcilant Puppet",
    Class = "Science",
    Health = 4,
    MoveSpeed = 2,
    Massive = true,
    Corpse = true,
    Image = "ReconcilantPuppet",
    ImageOffset = 14,
    SkillList = {"Heal_ReconcilantPuppet", "DeploySkill_ImpPuppet"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("ReconcilantPuppet") 



local a=ANIMS
a.ImpPuppet =a.MechUnit:new{Image="units/player/imppuppet.png", PosX = -15, PosY = -9}
a.ImpPuppeta = a.MechUnit:new{Image="units/player/imppuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.ImpPuppetw = a.MechUnit:new{Image="units/player/imppuppet_w.png", -15, PosY = -9}
a.ImpPuppet_broken = a.MechUnit:new{Image="units/player/imppuppet_broken.png", PosX = -15, PosY = -9 }
a.ImpPuppetw_broken = a.MechUnit:new{Image="units/player/imppuppet_w_broken.png", PosX = -15, PosY = -9 }
a.ImpPuppet_ns = a.MechIcon:new{Image="units/player/imppuppet_ns.png"}



local a=ANIMS
a.HowitzerPuppet =a.MechUnit:new{Image="units/player/howitzerpuppet.png", PosX = -15, PosY = -9}
a.HowitzerPuppeta = a.MechUnit:new{Image="units/player/howitzerpuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.HowitzerPuppetw = a.MechUnit:new{Image="units/player/howitzerpuppet_w.png", -15, PosY = -9}
a.HowitzerPuppet_broken = a.MechUnit:new{Image="units/player/howitzerpuppet_broken.png", PosX = -15, PosY = -9 }
a.HowitzerPuppetw_broken = a.MechUnit:new{Image="units/player/howitzerpuppet_w_broken.png", PosX = -15, PosY = -9 }
a.HowitzerPuppet_ns = a.MechIcon:new{Image="units/player/howitzerpuppet_ns.png"}


HowitzerPuppet = Pawn:new{
    Name = "Howitzer Puppet",
    Class = "Ranged",
    Health = 2,
    MoveSpeed = 1,
    Armor = true,
    Massive = true,
    Corpse = true,
    Image = "HowitzerPuppet",
    ImageOffset = 14,
    SkillList = {"HowitzerShelling","DeploySkill_HeraldPuppet"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("HowitzerPuppet") 

local a=ANIMS
a.HeraldPuppet =a.MechUnit:new{Image="units/player/heraldpuppet.png", PosX = -15, PosY = -9}
a.HeraldPuppeta = a.MechUnit:new{Image="units/player/heraldpuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.HeraldPuppetw = a.MechUnit:new{Image="units/player/heraldpuppet_w.png", -15, PosY = -9}
a.HeraldPuppet_broken = a.MechUnit:new{Image="units/player/heraldpuppet_broken.png", PosX = -15, PosY = -9 }
a.HeraldPuppetw_broken = a.MechUnit:new{Image="units/player/heraldpuppet_w_broken.png", PosX = -15, PosY = -9 }
a.HeraldPuppet_ns = a.MechIcon:new{Image="units/player/heraldpuppet_ns.png"}



local a=ANIMS
a.AnchoragePuppet =a.MechUnit:new{Image="units/player/anchoragepuppet.png", PosX = -15, PosY = -9}
a.AnchoragePuppeta = a.MechUnit:new{Image="units/player/anchoragepuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.AnchoragePuppetw = a.MechUnit:new{Image="units/player/anchoragepuppet_w.png", -15, PosY = -9}
a.AnchoragePuppet_broken = a.MechUnit:new{Image="units/player/anchoragepuppet_broken.png", PosX = -15, PosY = -9 }
a.AnchoragePuppetw_broken = a.MechUnit:new{Image="units/player/anchoragepuppet_w_broken.png", PosX = -15, PosY = -9 }
a.AnchoragePuppet_ns = a.MechIcon:new{Image="units/player/anchoragepuppet_ns.png"}

AnchoragePuppet = Pawn:new{
    Name = "Anchorage Puppet",
    Class = "Prime",
    Health = 4,
    MoveSpeed = 1,
    Massive = true,
    Corpse = true,
    Image = "AnchoragePuppet",
    ImageOffset = 14,
    SkillList = {"DeploySkill_Anchorage_Mixed","Anchorage_Beam"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("AnchoragePuppet")

local a=ANIMS
a.SerfPuppet =a.MechUnit:new{Image="units/player/serfpuppet.png", PosX = -15, PosY = -9}
a.SerfPuppeta = a.MechUnit:new{Image="units/player/serfpuppet_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.SerfPuppet_broken = a.MechUnit:new{Image="units/player/serfpuppet_broken.png", PosX = -15, PosY = -9 }
a.SerfPuppetw_broken = a.MechUnit:new{Image="units/player/serfpuppet_w_broken.png", PosX = -15, PosY = -9 }
a.SerfPuppet_ns = a.MechIcon:new{Image="units/player/serfpuppet_ns.png"}

local a=ANIMS
a.ColonyAnalogue =a.MechUnit:new{Image="units/player/colonyanalogue.png", PosX = -15, PosY = -9}
a.ColonyAnaloguea = a.MechUnit:new{Image="units/player/colonyanalogue_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.ColonyAnaloguew = a.MechUnit:new{Image="units/player/colonyanalogue_w.png",  PosX = -15, PosY = -9 }
a.ColonyAnalogue_broken = a.MechUnit:new{Image="units/player/colonyanalogue_broken.png", PosX = -15, PosY = -9 }
a.ColonyAnaloguew_broken = a.MechUnit:new{Image="units/player/colonyanalogue_w_broken.png", PosX = -15, PosY = -9 }
a.ColonyAnalogue_ns = a.MechIcon:new{Image="units/player/colonyanalogue_ns.png"}

local a=ANIMS
a.SovereigntyAnalogue =a.MechUnit:new{Image="units/player/sovereigntyanalogue.png", PosX = -15, PosY = -9}
a.SovereigntyAnaloguea = a.MechUnit:new{Image="units/player/sovereigntyanalogue_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.SovereigntyAnaloguew = a.MechUnit:new{Image="units/player/sovereigntyanalogue_w.png",  PosX = -15, PosY = -9 }
a.SovereigntyAnalogue_broken = a.MechUnit:new{Image="units/player/sovereigntyanalogue_broken.png", PosX = -15, PosY = -9 }
a.SovereigntyAnaloguew_broken = a.MechUnit:new{Image="units/player/sovereigntyanalogue_w_broken.png", PosX = -15, PosY = -9 }
a.SovereigntyAnalogue_ns = a.MechIcon:new{Image="units/player/sovereigntyanalogue_ns.png"}

SovereigntyAnalogue = Pawn:new{
    Name = "Sovereignty Analogue",
    Class = "Brute",
    Health = 3,
    MoveSpeed = 3,
    Massive = true,
    Armor = true,
    Corpse = true,
    Image = "SovereigntyAnalogue",
    ImageOffset = 15,
    SkillList = {"Sovereignty_Machinegun","Sovereignty_MagicMissile"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("SovereigntyAnalogue")

local a=ANIMS
a.ProvinceAnalogue =a.MechUnit:new{Image="units/player/provinceanalogue.png", PosX = -15, PosY = -9}
a.ProvinceAnaloguea = a.MechUnit:new{Image="units/player/provinceanalogue_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.ProvinceAnalogue_broken = a.MechUnit:new{Image="units/player/provinceanalogue_broken.png", PosX = -15, PosY = -9 }
a.ProvinceAnaloguew_broken = a.MechUnit:new{Image="units/player/provinceanalogue_w_broken.png", PosX = -15, PosY = -9 }
a.ProvinceAnalogue_ns = a.MechIcon:new{Image="units/player/provinceanalogue_ns.png"}

local a=ANIMS
a.FederationAnalogue =a.MechUnit:new{Image="units/player/federationanalogue.png", PosX = -15, PosY = -9}
a.FederationAnaloguea = a.MechUnit:new{Image="units/player/federationanalogue_a.png",  PosX = -15, PosY = -9, NumFrames = 4 }
a.FederationAnaloguew = a.MechUnit:new{Image="units/player/federationanalogue_w.png",  PosX = -15, PosY = -9 }
a.FederationAnalogue_broken = a.MechUnit:new{Image="units/player/federationanalogue_broken.png", PosX = -15, PosY = -9 }
a.FederationAnaloguew_broken = a.MechUnit:new{Image="units/player/federationanalogue_w_broken.png", PosX = -15, PosY = -9 }
a.FederationAnalogue_ns = a.MechIcon:new{Image="units/player/federationanalogue_ns.png"}

FederationAnalogue = Pawn:new{
    Name = "Federation Analogue",
    Class = "Science",
    Health = 4,
    MoveSpeed = 1,
    Massive = true,
    Armor = true,
    Corpse = true,
    Image = "FederationAnalogue",
    ImageOffset = 15,
    SkillList = {"Federation_BigShove","DeploySkill_ProvinceAnalogue"},
    SoundLocation = "/mech/prime/laser_mech/",
    DefaultTeam = TEAM_PLAYER,
    ImpactMaterial = IMPACT_METAL,
}
AddPawn("FederationAnalogue")