local mod = modApi:getCurrentMod()
local path = mod_loader.mods[modApi.currentMod].resourcePath
local weaponPath = path .."img/weapons/"

FreeAimArtillery = Skill:new{
	Name = "FreeAimBase",
	Description = "Artillery that can fire anywhere in an adjustable square range. Don't use this on its own, this is a base.",
	Class = "Ranged",
	Icon = "",
	UpShot = "effects/shot_artimech.png",
	ArtilleryStart = 2, --This is the inner bounds of the square. 1 = Adjacent tiles
	ArtillerySize = 5, --Determines the outer bounds of the square. 1 = Adjacent tiles
	BuildingDamage = true,
	DamageOuter = 0,
	DamageCenter = 1,
	CenterFire = 0,
	Push = 0,
	PowerCost = 0, --AE Change
	Damage = 1,---USED FOR TOOLTIPS
	BounceAmount = 1,
	Explosion = "",
	ExplosionCenter = "ExploArt1",
	ExplosionOuter = "",
	OuterAnimation = "airpush_",
	LaunchSound = "/weapons/artillery_volley",
	ImpactSound = "/impact/generic/explosion",
}

function FreeAimArtillery:GetTargetArea(point)
	local ret = PointList()
	local minrange = self.ArtilleryStart
	
	for dir = DIR_START, DIR_END do
		for i = minrange, self.ArtillerySize do
			local curr = Point(point + DIR_VECTORS[dir] * i)
			if not Board:IsValid(curr) then
				break
			end
			
			if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
				ret:push_back(curr)
			end

			for j = 1, self.ArtillerySize do
				local curralt = Point(curr + DIR_VECTORS[(dir+1)%4] * j)
				if not Board:IsValid(curralt) then
					break
				end
				
				if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
					ret:push_back(curralt)
				end
			end

			if minrange > 1 then
				for k = 1, (minrange - 1) do
					local curralt = Point(curr + DIR_VECTORS[(dir-1)%4] * k)
					if not Board:IsValid(curralt) then
						break
					end
					
					if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
						ret:push_back(curralt)
					end
				end
			end

		end
	end
	
	return ret
end

function FreeAimArtillery:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local damage = SpaceDamage(p2,self.DamageCenter)
	damage.sAnimation = self.ExplosionCenter
	damage.iFire = self.CenterFire

	if not self.BuildingDamage and Board:IsBuilding(p2) then		-- Target Buildings - 
		damage.iDamage = DAMAGE_ZERO
	end

	ret:AddArtillery(damage, self.UpShot)

	for dir = 0,3 do
		damage = SpaceDamage(p2 + DIR_VECTORS[dir],  self.DamageOuter)

		if not self.BuildingDamage and Board:IsBuilding(p2 + DIR_VECTORS[dir]) then		-- Target Buildings - 
			damage.iDamage = DAMAGE_ZERO
		end

		if self.Push == 1 then
			damage.iPush = dir
			damage.sAnimation = self.OuterAnimation..dir
		end

		ret:AddDamage(damage)
	end
	
	return ret
end

FreeAimArtilleryTwoClick = FreeAimArtillery:new{
	Name = "FreeAimBase",
	Description = "Artillery that can fire anywhere in an adjustable square range, twice. Don't use this on its own, this is a base.",
	Class = "Ranged",
	Icon = "",
	UpShot = "effects/shot_artimech.png",
	ArtilleryStart = 2, --This doesn't do anything even in the vanilla artillery calculations.
	ArtillerySize = 5, --Determines the outer bounds of the square. 
	BuildingDamage = true,
	TwoClick = true,
	--Push = 0,
	DamageOuter = 1,
	DamageCenter = 1,
	AcidEnhanced = 0,
	PowerCost = 0, --AE Change
	Damage = 1,---USED FOR TOOLTIPS
	BounceAmount = 1,
	Explosion = "",
	ExplosionCenter = "ExploArt1",
	ExplosionOuter = "",
	OuterAnimation = "airpush_",
	LaunchSound = "/weapons/artillery_volley",
	ImpactSound = "/impact/generic/explosion",
}

function FreeAimArtilleryTwoClick:GetSecondTargetArea(point)
	local ret = PointList()
	local minrange = self.ArtilleryStart
	
	for dir = DIR_START, DIR_END do
		for i = minrange, self.ArtillerySize do
			local curr = Point(point + DIR_VECTORS[dir] * i)
			if not Board:IsValid(curr) then
				break
			end
			
			if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
				ret:push_back(curr)
			end

			for j = 1, self.ArtillerySize do
				local curralt = Point(curr + DIR_VECTORS[(dir+1)%4] * j)
				if not Board:IsValid(curralt) then
					break
				end
				
				if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
					ret:push_back(curralt)
				end
			end

			if minrange > 1 then
				for k = 1, (minrange - 1) do
					local curralt = Point(curr + DIR_VECTORS[(dir-1)%4] * k)
					if not Board:IsValid(curralt) then
						break
					end
					
					if not self.OnlyEmpty or not Board:IsBlocked(curr,PATH_GROUND) then
						ret:push_back(curralt)
					end
				end
			end

		end
	end
	
	return ret
end

function FreeAimArtilleryTwoClick:GetFinalEffect(p1, p2, p3)
	local ret = SkillEffect()
	local damage = SpaceDamage(p2,self.DamageCenter)
	damage.sAnimation = self.ExplosionCenter
	damage.iFire = self.CenterFire

	if not self.BuildingDamage and Board:IsBuilding(p2) then		-- Target Buildings - 
		damage.iDamage = DAMAGE_ZERO
	end

	if Board:GetPawn(p2) ~= nil then
		if self.AcidEnhanced and Board:GetPawn(p2):IsAcid() then
			damage.iDamage = (self.Damage * 2)
		end
	end

	ret:AddArtillery(damage, self.UpShot)

	for dir = 0,3 do
		damage = SpaceDamage(p2 + DIR_VECTORS[dir],  self.DamageOuter)

		if not self.BuildingDamage and Board:IsBuilding(p2 + DIR_VECTORS[dir]) then		-- Target Buildings - 
			damage.iDamage = DAMAGE_ZERO
		end

		if self.Push == 1 then
			damage.iPush = dir
			damage.sAnimation = self.OuterAnimation..dir
		end

		ret:AddDamage(damage)
	end

	damage = SpaceDamage(p3,self.DamageCenter)
	damage.sAnimation = self.ExplosionCenter
	damage.iFire = self.CenterFire

	if Board:GetPawn(p3) ~= nil then
		if self.AcidEnhanced and Board:GetPawn(p3):IsAcid() then
			damage.iDamage = (self.Damage * 2)
		end
	end

	if not self.BuildingDamage and Board:IsBuilding(p2) then		-- Target Buildings - 
		damage.iDamage = DAMAGE_ZERO
	end

	ret:AddArtillery(damage, self.UpShot)

	for dir = 0,3 do
		damage = SpaceDamage(p3 + DIR_VECTORS[dir],  self.DamageOuter)

		if not self.BuildingDamage and Board:IsBuilding(p2 + DIR_VECTORS[dir]) then		-- Target Buildings - 
			damage.iDamage = DAMAGE_ZERO
		end

		if self.Push == 1 then
			damage.iPush = dir
			damage.sAnimation = self.OuterAnimation..dir
		end

		ret:AddDamage(damage)
	end
	
	return ret
end

-- A beam that starts a distance out from the target, travelling perpendicular to its origin direction and pushing in the original direction.
Perpendicular_Beam = Skill:new{
	Damage = 1,
	BeamRange = 3, -- The beam hits this number of tiles
	PowerCost = 0,
	Smoke = 0,
	Acid = 0,
	Fire = 0,
	Freeze = 0,
	TwoClick = true,
	FriendlyDamage = true,
	StrafeExplosion = "explopush1_",
	LaserAnimation = "ExploAir1",
	LaserArt = "effects/laser1",
	LaunchSound = "/weapons/burst_beam"
}

function Perpendicular_Beam:GetTargetArea(point)
	local ret = PointList()
	for dir = DIR_START, DIR_END do
		for i = 1,8 do
			local curr = point + DIR_VECTORS[dir]*i
			while Board:IsValid(curr) do
				ret:push_back(curr)
				curr = curr + DIR_VECTORS[dir]
			end
			
			if Board:IsValid(curr) then
				ret:push_back(curr)
			end
		end
	end
	
	return ret
end

function Perpendicular_Beam:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local pushdir = GetDirection(p2-p1)
	local damage = SpaceDamage(p2,self.Damage)
	if not self.FriendlyDamage and ( Board:IsPawnTeam(p2, TEAM_PLAYER) or Board:IsBuilding(p2) ) then damage.iDamage = 0 else damage.iPush = pushdir end
	ret:AddDamage(damage)
	return ret
end

function Perpendicular_Beam:GetSecondTargetArea(p1,p2)
-- Pick a perpendicular direction for the "beam" to move.
	local ret = PointList()
	local direction = GetDirection(p2-p1)

	local dir = (direction+1)%4
	local curr = Point(p2 + DIR_VECTORS[dir])
	ret:push_back(curr)

	dir = (direction+3)%4
	curr = Point(p2 + DIR_VECTORS[dir])
	ret:push_back(curr)

	return ret
end

function Perpendicular_Beam:GetFinalEffect(p1,p2,p3)
	local ret = SkillEffect()
	local pushdir = GetDirection(p2-p1)
	local traveldir = GetDirection(p3-p2)
	local damage = SpaceDamage(p2,self.Damage)
	local fakedamage = SpaceDamage(p2,DAMAGE_ZERO)
	local beamtraverse = self.BeamRange
	local i = 0
	while beamtraverse > 0 do
		damage.iDamage = self.Damage --Just in case the initial tile was friendly.
		damage.iPush = pushdir --Dittoh
		damage.sAnimation = self.StrafeExplosion..pushdir
		local target = p2 + DIR_VECTORS[traveldir] * i
		if not self.FriendlyDamage and ( Board:IsPawnTeam(target, TEAM_PLAYER) or Board:IsBuilding(target) ) then
			fakedamage.loc = target
			ret:AddDamage(fakedamage)
		else
			ret:AddDelay(0.1)
			damage.loc = target
			ret:AddDamage(damage)
			beamtraverse = (beamtraverse - 1)
		end
		if i > 0 and Board:IsValid(target) then
			local beamstart = p2 + DIR_VECTORS[traveldir] * (i-1)
			local beamend = SpaceDamage(target,0)
			ret:AddProjectile(beamstart,beamend,self.LaserArt,FULL_DELAY)
		end
		i = i + 1
	end
	return ret
end